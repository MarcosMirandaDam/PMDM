package com.example.llenarspinnerconotro;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //definir unidades de almacenamiento
    List<String> listaHerramientas;         //llenaremos despues con el array de herrmamienta

    //declaramos el spinner
    private Spinner spHerramientas;
    private Spinner spListadoCarro;

    // declaramos variables del diseño

    private TextView tvTitulo, tvEtiSeleccionaHerramienta, tvEtiContenido;
    private Button botonAniadir, botonRetirar;

    //declaramos el adaptador del spinner
    private ArrayAdapter<CharSequence> adaptadorHerramientas;

    private ArrayAdapter<String> adaptadorListadoCarro;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();

        configurarSpinnerHerramientas();

        configurarSpinnerListadoCarro();

        setlistenertobuttons();


    }

    private void setlistenertobuttons() {
        botonAniadir.setOnClickListener(this::onClik);
        botonRetirar.setOnClickListener(this::onClik);
    }

    private void onClik(View view) {
        //cogemos el dato seleccionado
        String herramientaElegida = (String) spHerramientas.getSelectedItem();
        int pos = adaptadorListadoCarro.getPosition(herramientaElegida);   // la pos en el adaptador que se llena dinamicamente
        if (view.getId() == R.id.botonAniadir) {
            if (pos < 0) {
                adaptadorListadoCarro.add(herramientaElegida);
                adaptadorHerramientas.notifyDataSetChanged();
                spListadoCarro.setSelection(adaptadorListadoCarro.getPosition(herramientaElegida));
            } else {
                Toast.makeText(this, "Ese producto ya está en el carrito", Toast.LENGTH_SHORT).show();
            }

        } else {
            if (pos >= 0) {
                adaptadorListadoCarro.remove(herramientaElegida);
                adaptadorListadoCarro.notifyDataSetChanged();

            } else {
                Toast.makeText(this, "Ese producto no está en el listado", Toast.LENGTH_SHORT).show();
            }

        }
    }

    private void configurarSpinnerListadoCarro() {
        //iniciamos el arrayList
        listaHerramientas = new ArrayList<>();
        //configuramos el spinner ¡¡ ojo le pasamos la lista al final !!!
        adaptadorListadoCarro = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, listaHerramientas);
        adaptadorListadoCarro.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spListadoCarro.setAdapter(adaptadorListadoCarro);
        spListadoCarro.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                String elegido = adapterView.getItemAtPosition(position).toString();
                Toast.makeText(MainActivity.this, "Has elegido " + elegido, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(MainActivity.this, "No has elegido nada", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void configurarSpinnerHerramientas() {
        adaptadorHerramientas = ArrayAdapter.createFromResource(this, R.array.herramientas, android.R.layout.simple_spinner_item);
        adaptadorHerramientas.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spHerramientas.setAdapter(adaptadorHerramientas);
        //accion de cada item elegido
        spHerramientas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                String elegido = adapterView.getItemAtPosition(position).toString();
                Toast.makeText(MainActivity.this, "Has elegido " + elegido, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(MainActivity.this, "No has elegido nada", Toast.LENGTH_SHORT).show();
            }
        });

    }

    private void initReferences() {
        tvTitulo = findViewById(R.id.tvTitulo);
        tvEtiSeleccionaHerramienta = findViewById(R.id.tvEtiSeleccionaHerramienta);
        spHerramientas = findViewById(R.id.spHerramientas);
        spListadoCarro = findViewById(R.id.spListadoCarro);
        tvEtiContenido = findViewById(R.id.tvEtiContenido);
        botonAniadir = findViewById(R.id.botonAniadir);
        botonRetirar = findViewById(R.id.botonRetirar);

    }
}