package com.example.monumentos_marcos_miranda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class PantallaDetalle extends AppCompatActivity {

    //creamos las variables
    ImageView ivMonumento;
    TextView tvDescripcion,tvNombre;
    String descripcion="";
    int numero;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_detalle);

        tvNombre=findViewById(R.id.tvNombre);
        tvDescripcion = findViewById(R.id.tvDescripcion);
        ivMonumento=findViewById(R.id.ivMonumento);

        //recuperar los datos de la activity principal

        Intent i = getIntent();
        descripcion = i.getStringExtra(MainActivity.EXTRA_DESCRIPCION);
        tvDescripcion.setText(descripcion);
        numero=i.getIntExtra(MainActivity.EXTRA_IMAGEN,0);
        pasarFoto(numero);

        }


        // establecemos texto, imagen y titulo de cada monumento
    private void pasarFoto (int i){
            switch(i){
                case 0:
                    tvNombre.setText(MainActivity.listaMonumentos.get(0).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(0).getFotoId());
                    tvDescripcion.setText(MainActivity.listaMonumentos.get(0).toStringDetalleCompleto());
                    break;
                    case 1:
                    tvNombre.setText(MainActivity.listaMonumentos.get(1).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(1).getFotoId());
                    tvDescripcion.setText(MainActivity.listaMonumentos.get(1).toStringDetalleCompleto());
                    break;
                    case 2:
                    tvNombre.setText(MainActivity.listaMonumentos.get(2).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(2).getFotoId());
                    tvDescripcion.setText(MainActivity.listaMonumentos.get(2).toStringDetalleCompleto());
                    break;
                    case 3:
                    tvNombre.setText(MainActivity.listaMonumentos.get(3).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(3).getFotoId());
                    tvDescripcion.setText(MainActivity.listaMonumentos.get(3).toStringDetalleCompleto());
                    break;
                    case 4:
                    tvNombre.setText(MainActivity.listaMonumentos.get(4).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(4).getFotoId());
                    tvDescripcion.setText(MainActivity.listaMonumentos.get(4).toStringDetalleCompleto());
                    break;
                    case 5:
                    tvNombre.setText(MainActivity.listaMonumentos.get(5).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(5).getFotoId());
                    tvDescripcion.setText(MainActivity.listaMonumentos.get(5).toStringDetalleCompleto());
                    break;

            }
        }

       }