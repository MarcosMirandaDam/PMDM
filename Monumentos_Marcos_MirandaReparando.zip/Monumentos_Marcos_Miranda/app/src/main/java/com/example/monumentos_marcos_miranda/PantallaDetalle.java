package com.example.monumentos_marcos_miranda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class PantallaDetalle extends AppCompatActivity {

    //creamos las variables
    ImageView ivMonumento;
    EditText etDescripcion,etNombre;
    String descripcion="";
    int numero;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_detalle);

        etNombre=findViewById(R.id.etNombre);
        etDescripcion = findViewById(R.id.etDescripcion);
        ivMonumento=findViewById(R.id.ivMonumento);

        //recuperar los datos de la activity principal

        Intent i = getIntent();
        descripcion = i.getStringExtra(MainActivity.EXTRA_DESCRIPCION);
        etDescripcion.setText(descripcion);
        numero=i.getIntExtra(MainActivity.EXTRA_IMAGEN,0);
        pasarFoto(numero);

        }


        // establecemos texto, imagen y titulo de cada monumento
    private void pasarFoto (int i){
            switch(i){
                case 0:
                    etNombre.setText(MainActivity.listaMonumentos.get(0).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(0).getFotoId());
                    etDescripcion.setText(MainActivity.listaMonumentos.get(0).toStringDetalleCompleto());
                    break;
                    case 1:
                    etNombre.setText(MainActivity.listaMonumentos.get(1).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(1).getFotoId());
                    etDescripcion.setText(MainActivity.listaMonumentos.get(1).toStringDetalleCompleto());
                    break;
                    case 2:
                    etNombre.setText(MainActivity.listaMonumentos.get(2).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(2).getFotoId());
                    etDescripcion.setText(MainActivity.listaMonumentos.get(2).toStringDetalleCompleto());
                    break;
                    case 3:
                    etNombre.setText(MainActivity.listaMonumentos.get(3).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(3).getFotoId());
                    etDescripcion.setText(MainActivity.listaMonumentos.get(3).toStringDetalleCompleto());
                    break;
                    case 4:
                    etNombre.setText(MainActivity.listaMonumentos.get(4).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(4).getFotoId());
                    etDescripcion.setText(MainActivity.listaMonumentos.get(4).toStringDetalleCompleto());
                    break;
                    case 5:
                    etNombre.setText(MainActivity.listaMonumentos.get(5).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(5).getFotoId());
                    etDescripcion.setText(MainActivity.listaMonumentos.get(5).toStringDetalleCompleto());
                    break;

            }
        }

       }