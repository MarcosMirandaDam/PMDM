package com.example.monumentos_marcos_miranda;

import android.graphics.Bitmap;

public class Monumento {

    private String idMonumento;
    private String nombre;
    private String ubicacion;
    private int anoFabricacion;
    private Arquitecto arquitecto;
    private String descripcion;
    private boolean patrimonioMundial;
    private String estiloArquitectonico;
    private int altura, fotoId;



       public Monumento(String idMonumento,String nombre, String ubicacion, int anoFabricacion, String nombreArquitecto,String sexo,String pais, String descripcion, boolean patrimonioMundial, String estiloArquitectonico, int altura,int fotoId) {
        this.idMonumento=idMonumento;
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.anoFabricacion = anoFabricacion;
        this.arquitecto = new Arquitecto(nombreArquitecto,sexo,pais);
        this.descripcion = descripcion;
        this.patrimonioMundial = patrimonioMundial;
        this.estiloArquitectonico = estiloArquitectonico;
        this.altura = altura;
        this.fotoId=fotoId;

    }



    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

   public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public Arquitecto getArquitecto() {
        return arquitecto;
    }

    public void setArquitecto(Arquitecto arquitecto) {
        this.arquitecto = arquitecto;
    }

    public boolean isPatrimonioMundial() {
        return patrimonioMundial;
    }

    public void setPatrimonioMundial(boolean patrimonioMundial) {
        this.patrimonioMundial = patrimonioMundial;
    }

    public String getEstiloArquitectonico() {
        return estiloArquitectonico;
    }

    public void setEstiloArquitectonico(String estiloArquitectonico) {
        this.estiloArquitectonico = estiloArquitectonico;
    }

    public String getIdMonumento() {
        return idMonumento;
    }

    public void setIdMonumento(String idMonumento) {
        this.idMonumento = idMonumento;
    }

    public int getAnoFabricacion() {
        return anoFabricacion;
    }

    public void setAnoFabricacion(int anoFabricacion) {
        this.anoFabricacion = anoFabricacion;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }

    public int getFotoId() {
        return fotoId;
    }

    public void setFotoId(int fotoId) {
        this.fotoId = fotoId;
    }

    public String toStringCorto() {
        return "" +
                "Nombre:"+nombre+ "\n" +
                "Ubicacion:"+ubicacion+ "\n" +
                "Descripcion:"+descripcion+ "";
    }

    public String toStringDetalleCompleto() {
        return "" +
                "Nombre:" +nombre+ "\n" +
                "Ubicacion:"+ubicacion+ "\n" +
                "Año de Fabricacion:"+anoFabricacion+ "\n" +
                "Arquitecto:"+arquitecto+ "\n" +
                "Descripcion:"+descripcion+ "\n" +
                "Patrimonio Mundial:"+patrimonioMundial+ "\n" +
                "Estilo Arquitectonico:"+estiloArquitectonico+ "\n" +
                "Altura:"+altura+ " metros" +
                "";
    }
}
