package com.example.monumentos_marcos_miranda;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    //creamos la lista de monumentos para almacenarlos a partir de la clase Monumento creada.
    public static List<Monumento> listaMonumentos = Arrays.asList(
            new Monumento("1", "Arco Santa Maria", "España, Burgos", 1553, "Francisco de Colonia", "Hombre", "España", "El Arco de Santa María es uno de los monumentos más visitados y emblemáticos de la ciudad de Burgos.", true,"Marcos",34,R.drawable.arco_santa_maria),
            new Monumento("2", "Catedral Sta.Maria", "España, Burgos", 1221, "Marcos Miranda", "Hombre", "España", "La Santa Iglesia Catedral Basílica Metropolitana de Santa María es un templo catedralicio de culto católico dedicado a la Virgen María, en la ciudad española de Burgos. Pertenece a la archidiócesis de Burgos.", true,"Gotico",89,R.drawable.catedral_burgos),
            new Monumento("3", "Cartuja Miraflores", "España, Burgos", 1441, "Juan de Colonia", "Hombre", "España", "La Cartuja de Santa María de Miraflores es un monasterio de la Orden de los Cartujos, edificado en una loma conocida como Miraflores, situada a unos tres kilómetros del centro de la ciudad de Burgos. Es una joya del arte gótico final", true,"Gotico",89,R.drawable.cartuja),
            new Monumento("4", "Casa Cordón", "España, Burgos", 1968, "Juan de Colonia", "Hombre", "Si", "El palacio de los Condestables de Castilla, conocido popularmente como casa del Cordón, es un palacio originario del siglo XV que se alza en el casco histórico de Burgos, presidiendo la antigua plaza del Mercado Mayor, que estaba formada por las actuales plazas de La Libertad y Santo Domingo de Guzmán", true,"Gotico",24,R.drawable.cordon),
            new Monumento("5", "El Cid", "España, Burgos", 1955, "Fernando Chueca Goitia", "Hombre", "Si", "El Monumento al Cid Campeador es una estatua ecuestre situada en la ciudad de Burgos, en España, y representa a Rodrigo Díaz de Vivar, un líder militar castellano que llegó a dominar al frente de su propia mesnada el Levante de la península ibérica a finales del siglo XI", false,"Gotico",10,R.drawable.el_cid),
            new Monumento("6", "Monasterio Las Huelgas", "España, Burgos", 1181, "Chus Pereda", "Hombre", "España", "El monasterio de Santa María la Real de las Huelgas, conocido popularmente como monasterio de las Huelgas,situado en la ciudad de Burgos, es un monasterio de la congregación de monasterios de monjas cistercienses de San Bernardo", false,"Cisterciense",34,R.drawable.huelgas)
            );


    //declaramos las vistas necesarias
    private TextView tvBienvenida, tvDescripcion,tvTitulo;
    private ImageView ivMonumento;
    private Button botonOtro;

    private Button botonVerDetalles;

    // declaramos la constante para pasar dato a la segunda pantalla(activity)
    public final static String EXTRA_DESCRIPCION="descripcion";
    public final static String EXTRA_IMAGEN="imagen";



    // variable que recogeré el valor del random
    int numero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();

        //lanzamos el random
        hacerRandom();

        // accion del boton verDetalles.... lanzará a la segunda activity
        botonVerDetalles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lanzarPantallaDetalle();
            }
        });

        // boton que cambia el monumento que se esta visualizando en la pantalla principal
        botonOtro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero=hacerRandom();
            }
        });


    }



    // metodo privado que lanza la otra pantalla de detalle
    private void lanzarPantallaDetalle() {
        Intent iPantallaDetalle = new Intent(this, PantallaDetalle.class);

        // pasamos los textos de la pantalla principal

        String descripcion= tvDescripcion.getText().toString();

        //creamos Bundle para pasar grupo de constantes
        Bundle bundle=new Bundle();

        bundle.putString(EXTRA_DESCRIPCION, descripcion);
        bundle.putInt(EXTRA_IMAGEN,numero);

        iPantallaDetalle.putExtras(bundle);

        startActivity(iPantallaDetalle);


    }



    //hacemos el random para que salga la imagen y su descripcion
    private int hacerRandom() {
        Random random = new Random();
        int numero = random.nextInt(6);
        switch (numero){
            case 0:
            ivMonumento.setImageResource(listaMonumentos.get(0).getFotoId());
            tvDescripcion.setText(listaMonumentos.get(numero).toStringCorto());
            break;

            case 1:
            ivMonumento.setImageResource(listaMonumentos.get(1).getFotoId());
            tvDescripcion.setText(listaMonumentos.get(numero).toStringCorto());
            break;

            case 2:
            ivMonumento.setImageResource(listaMonumentos.get(2).getFotoId());
            tvDescripcion.setText(listaMonumentos.get(numero).toStringCorto());
            break;

            case 3:
            ivMonumento.setImageResource(listaMonumentos.get(3).getFotoId());
            tvDescripcion.setText(listaMonumentos.get(numero).toStringCorto());
            break;

            case 4:
            ivMonumento.setImageResource(listaMonumentos.get(4).getFotoId());
            tvDescripcion.setText(listaMonumentos.get(numero).toStringCorto());
             break;

            case 5:
                ivMonumento.setImageResource(listaMonumentos.get(5).getFotoId());
                tvDescripcion.setText(listaMonumentos.get(numero).toStringCorto());
                break;

        }

      return numero;
    }



    //metodo privado que inicializa las vistas xml
    private void initReferences(){
        tvTitulo=findViewById(R.id.textViewTitulo);
        tvBienvenida=findViewById(R.id.tvBienvenida);
        tvDescripcion=findViewById(R.id.tvDescripcion);
        botonVerDetalles=findViewById(R.id.botonDetalles);
        botonOtro=findViewById(R.id.botonOtro);
        ivMonumento=findViewById(R.id.ivMonumento);
    }

    /**
     * metodo para guardar datos cambio de pantalla
     * @param outState Bundle in which to place your saved state.
     *
     */
    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putString("descripcion",tvDescripcion.getText().toString());
        outState.putInt("imagen",numero);
    }

    /**
     * metodo recuperar datos cambio de pantalla
     * @param savedInstanceState the data most recently supplied in {@link #onSaveInstanceState}.
     *
     */
    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        tvDescripcion.setText(savedInstanceState.getString("descripcion"));
        ivMonumento.setId(savedInstanceState.getInt("imagen",numero));
    }
}