package com.example.spinnermasrecyclerclase;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class PantallaConcesionario extends AppCompatActivity {

    //variable que usamos para tomar la marca que viene de la pantalla principal
    static String marcaSeleccionada;

    // variables del diseño
    private TextView tvMarca,tvEtiConcesionario;

    // lista que contiene los objetos coche
    static List<Coche> listaCochesMazda;
    static List<Coche> listaCochesRenault;


    // recyclerview de coches
    private RecyclerView rvCoches;

    // adaptador

    private AdaptadorCoches adaptadorCoches;
    private AdaptadorCochesRenault adaptadorCochesRenault;








    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_concesionario);

        initReferences();

        //recogemos el dato que viene de la primera pantalla
        Intent i=getIntent();
        if(i.hasExtra(MainActivity.EXTRA_MARCA)){
            marcaSeleccionada=i.getStringExtra(MainActivity.EXTRA_MARCA);
            tvMarca.setText(marcaSeleccionada);
        }

        //cargar datos mazda a la recycler

        cargarDatosMazda();
        cargarDatosRenault();



        //configurar recycler
        configurarRecyclerViewCoches();



    }

    private void configurarRecyclerViewCoches() {
        if (marcaSeleccionada.equalsIgnoreCase("Mazda")) {
            adaptadorCoches = new AdaptadorCoches((listaCochesMazda));
            adaptadorCoches.setOnItemClickListener(new AdaptadorCoches.OnItemClickListener() {
                @Override
                public void onItemClick(int posicion) {

                }


            });
            rvCoches.setAdapter(adaptadorCoches);
            rvCoches.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));
        } else if (marcaSeleccionada.equalsIgnoreCase("Renault")) {
            adaptadorCochesRenault = new AdaptadorCochesRenault((listaCochesRenault));
            adaptadorCochesRenault.setOnItemClickListener(new AdaptadorCochesRenault.OnItemClickListener() {
                @Override
                public void onItemClick(int posicion) {

                }
            });
            rvCoches.setAdapter(adaptadorCochesRenault);
            rvCoches.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false));

        }
    }

    private void cargarDatosMazda() {

        String[] modelos=getResources().getStringArray(R.array.modelos_mazda);
        int[] precios=getResources().getIntArray(R.array.precios_mazda);
        TypedArray arrayImagenes = getResources().obtainTypedArray(R.array.imagenes_mazda);
        Drawable[] imagenesMazda = new Drawable[arrayImagenes.length()];
        for (int i = 0; i < imagenesMazda.length; i++) {
            imagenesMazda[i] = arrayImagenes.getDrawable(i);

        }
        //rellenamos el arrayList de coches mazda
        listaCochesMazda = new ArrayList<>();
        for (int i = 0; i < imagenesMazda.length; i++) {
            listaCochesMazda.add(new Coche("Mazda", modelos[i], precios[i], imagenesMazda[i]));

        }
    }

    private void cargarDatosRenault() {

        String[] modelos=getResources().getStringArray(R.array.modelos_renault);
        int[] precios=getResources().getIntArray(R.array.precios_renault);
        TypedArray arrayImagenes = getResources().obtainTypedArray(R.array.imagenes_renault);
        Drawable[] imagenesRenault = new Drawable[arrayImagenes.length()];
        for (int i = 0; i < imagenesRenault.length; i++) {
            imagenesRenault[i] = arrayImagenes.getDrawable(i);

        }
        //rellenamos el arrayList de coches mazda
        listaCochesRenault = new ArrayList<>();
        for (int i = 0; i < imagenesRenault.length; i++) {
            listaCochesRenault.add(new Coche("Renault", modelos[i], precios[i], imagenesRenault[i]));

        }
    }



    private void initReferences() {
        tvMarca=findViewById(R.id.tvMarca);
        tvEtiConcesionario=findViewById(R.id.tvEtiConcesionario);
        rvCoches=findViewById(R.id.rvCoches);
    }
}