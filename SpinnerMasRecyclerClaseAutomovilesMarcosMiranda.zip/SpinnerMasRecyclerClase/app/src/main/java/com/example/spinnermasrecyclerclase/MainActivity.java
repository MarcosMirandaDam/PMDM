package com.example.spinnermasrecyclerclase;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private TextView tvEncabezado, tvMarcasDisponibles,tvMarca,tvEtiValorTotal,tvValorTotalMarca;
    private Button botonAcceder;
    private Spinner spMarcasCoches;

    private ImageView ivLogoMarca;

    private ArrayAdapter<CharSequence> adaptadorMarcasCoche;

    //launcher
    private ActivityResultLauncher<Intent> launcherConcesionario;

    //constante que vamos a pasar a la segunda pantalla
    public static String EXTRA_MARCA = "marca";
    private String marcaSeleccionada;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();

        configurarSpinnerMarcasCoche();

        launcherConcesionario = registroDevolucionDato();

        botonAcceder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lanzarPantallaConcesionario();
            }
        });




    }

    private void lanzarPantallaConcesionario() {
        //pasamos el dato deseado a la segunda pantalla
        marcaSeleccionada = EXTRA_MARCA;
        Intent iPantallaConcesionario = new Intent(this, PantallaConcesionario.class);
        iPantallaConcesionario.putExtra(EXTRA_MARCA, marcaSeleccionada);
        launcherConcesionario.launch(iPantallaConcesionario);
    }

    private ActivityResultLauncher<Intent> registroDevolucionDato() {
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if (result.getResultCode() == RESULT_OK) {
                            Intent data = result.getData();
                            completarCampos(data);

                        }
                    }
                });
    }

    private void completarCampos(Intent data) {
        //aqui completamos lo que vuelva de la segunda pantalla
        tvValorTotalMarca.setText(data.getStringExtra(PantallaConcesionario.EXTRA_VALOR_TOTAL));
    }

    private void configurarSpinnerMarcasCoche() {
        adaptadorMarcasCoche = ArrayAdapter.createFromResource(this, R.array.marcas_coches, android.R.layout.simple_spinner_item);
        adaptadorMarcasCoche.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spMarcasCoches.setAdapter(adaptadorMarcasCoche);
        spMarcasCoches.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                marcaSeleccionada = adapterView.getItemAtPosition(position).toString();
                EXTRA_MARCA = marcaSeleccionada;
                tvMarca.setText(marcaSeleccionada);
                if(marcaSeleccionada.equalsIgnoreCase("Mazda")){
                    ivLogoMarca.setImageResource(R.drawable.logomazda);
                } else if (marcaSeleccionada.equalsIgnoreCase("Renault")){
                    ivLogoMarca.setImageResource(R.drawable.logorenault);
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

    private void initReferences() {
        tvEncabezado = findViewById(R.id.tvEncabezado);
        spMarcasCoches = findViewById(R.id.spMarcasCoches);
        tvMarcasDisponibles = findViewById(R.id.tvEtiMarcas);
        tvMarca = findViewById(R.id.tvMarca);
        tvEtiValorTotal = findViewById(R.id.tvEtiValorTotal);
        tvValorTotalMarca = findViewById(R.id.tvValorTotalMarca);
        ivLogoMarca = findViewById(R.id.ivLogoMarca);
        botonAcceder=findViewById(R.id.botonAcceder);

    }
}