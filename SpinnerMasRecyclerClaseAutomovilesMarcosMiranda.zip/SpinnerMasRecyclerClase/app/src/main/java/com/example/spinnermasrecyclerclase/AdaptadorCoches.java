package com.example.spinnermasrecyclerclase;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdaptadorCoches extends RecyclerView.Adapter<AdaptadorCoches.CochesViewHolder> {

    //listas que almacenan los datos
    List<Coche> listaCochesMazda;

    public AdaptadorCoches(List<Coche> listaCochesMazda) {
        this.listaCochesMazda = listaCochesMazda;
    }

    private OnItemClickListener mListener;

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.mListener = listener;
    }

    public interface OnItemClickListener {
        void onItemClick(int posicion);

    }

    @NonNull
    @Override
    public AdaptadorCoches.CochesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista_coches, parent, false);
        return new CochesViewHolder(itemView, mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorCoches.CochesViewHolder holder, int position) {

        Coche coche = listaCochesMazda.get(position);
        holder.bindCoche(coche);

    }

    @Override
    public int getItemCount() {

        return listaCochesMazda.size();
    }

    public static class CochesViewHolder extends RecyclerView.ViewHolder {
        private ImageView ivCoche;
        private TextView tvMarca, tvModelo, tvPrecio;


        public CochesViewHolder(@NonNull View itemView, OnItemClickListener listener) {
            super(itemView);
            //asignando el listener de clicks
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // llamo a mi listener pasándole el equipo sobre el que se hizo click y su posición
                    if (listener != null) {
                        listener.onItemClick(getAdapterPosition());
                    }
                }
            });
            //vistas de los componentes
            ivCoche = itemView.findViewById(R.id.ivCoche);
            tvMarca = itemView.findViewById(R.id.tvMarca);
            tvModelo = itemView.findViewById(R.id.tvModelo);
            tvPrecio = itemView.findViewById(R.id.tvPrecio);

        }

        public void bindCoche(Coche coche) {
            ivCoche.setImageDrawable(coche.getImagen());
            tvMarca.setText(coche.getMarca());
            tvModelo.setText(coche.getModelo());
            tvPrecio.setText(String.valueOf(coche.getPrecio()));

        }
    }
}
