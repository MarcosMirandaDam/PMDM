package com.example.recyclerviewherramientas;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdaptadorHerramientas extends RecyclerView.Adapter<AdaptadorHerramientas.HerramientasViewHolder> {
    //lista que almacena los datos
    List<Herramienta> listaHerramientas;

    //constructor


    public AdaptadorHerramientas(List<Herramienta> listaHerramientas) {
        this.listaHerramientas = listaHerramientas;
    }

    // escuchador onitemclik
    private OnItemClickListener mListener;
    public void setOnItemClickListener(OnItemClickListener listener){
        this.mListener=listener;
    }
    //interface
    public interface OnItemClickListener{
        void onItemClick(int posicion);
    }


    @NonNull
    @Override
    public AdaptadorHerramientas.HerramientasViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista_herramientas,parent,false);
        return new HerramientasViewHolder(itemView,mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorHerramientas.HerramientasViewHolder holder, int position) {
    Herramienta herramienta=listaHerramientas.get(position);
    holder.bindHerramienta(herramienta);
    }

    @Override
    public int getItemCount() {
        return listaHerramientas.size();
    }

    public static class HerramientasViewHolder extends RecyclerView.ViewHolder{
        private ImageView ivHerramienta;
        private TextView tvMarca,tvDenominacion,tvIdHerramienta;

        public HerramientasViewHolder(@NonNull View itemView,OnItemClickListener listener) {
            super(itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // llamo a mi listener pasándole el equipo sobre el que se hizo click y su posición
                    if (listener != null) {
                        listener.onItemClick(getAdapterPosition());
                    }
                }
            });
            ivHerramienta=itemView.findViewById(R.id.ivHerramienta);
            tvMarca=itemView.findViewById(R.id.tvMarca);
            tvDenominacion=itemView.findViewById(R.id.tvDenominacion);
            tvIdHerramienta=itemView.findViewById(R.id.tvIdHerramienta);


        }

        public void bindHerramienta(Herramienta herramienta) {
            ivHerramienta.setImageResource(herramienta.getIdImagen());
            tvMarca.setText(herramienta.getMarca());
            tvDenominacion.setText(herramienta.getDenominacion());
            tvIdHerramienta.setText(herramienta.getIdHerramienta());

        }
    }
}
