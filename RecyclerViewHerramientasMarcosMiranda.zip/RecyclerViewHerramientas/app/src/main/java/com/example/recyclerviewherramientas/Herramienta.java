package com.example.recyclerviewherramientas;

public class Herramienta {

    private String marca,denominacion,tipo,idHerramienta;
    private int idImagen;

    public Herramienta(String idHerramienta, String marca, String denominacion, String tipo, int idImagen) {
        this.idHerramienta=idHerramienta;
        this. marca = marca;
        this.denominacion = denominacion;
        this.tipo = tipo;
        this.idImagen = idImagen;
    }

    public String getIdHerramienta() {
        return idHerramienta;
    }

    public void setIdHerramienta(String idHerramienta) {
        this.idHerramienta = idHerramienta;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        marca = marca;
    }

    public String getDenominacion() {
        return denominacion;
    }

    public void setDenominacion(String denominacion) {
        this.denominacion = denominacion;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public int getIdImagen() {
        return idImagen;
    }

    public void setIdImagen(int idImagen) {
        this.idImagen = idImagen;
    }

    @Override
    public String toString() {
        return "Herramienta{" +
                "marca='" + marca + '\'' +
                ", denominacion='" + denominacion + '\'' +
                ", tipo='" + tipo + '\'' +
                ", idHerramienta='" + idHerramienta + '\'' +
                ", idImagen=" + idImagen +
                '}';
    }
}
