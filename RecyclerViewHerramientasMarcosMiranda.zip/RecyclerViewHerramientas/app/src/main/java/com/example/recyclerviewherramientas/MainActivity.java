package com.example.recyclerviewherramientas;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //unidad de almacenamiento
    public static List<Herramienta> listaHerramientas=new ArrayList<>();

    public List<Herramienta> getListaHerramientas(){
        listaHerramientas.add(new Herramienta("1","Bosch","Bolsa Herramientas","almacenaje",R.drawable.bolsaherramientas));
        listaHerramientas.add(new Herramienta("2","Dremel","Caja Herramientas","almacenaje",R.drawable.cajaherramientas));
        listaHerramientas.add(new Herramienta("3","Raptor","Disco Diamante","utiles",R.drawable.discodiamante));
        listaHerramientas.add(new Herramienta("4","Irimo","Juego Carraca","utiles",R.drawable.juegocarraca));
        listaHerramientas.add(new Herramienta("5","Bosch","Martillo Electrico","electricidad",R.drawable.martilloelectrico));
        listaHerramientas.add(new Herramienta("6","Bosch","Radial","electricidad",R.drawable.radial));
        listaHerramientas.add(new Herramienta("7","Bosch","Taladro electrico","electricidad",R.drawable.taladro));

        return listaHerramientas;
    }

    //variables del diseño

    private TextView tvEncabezado;
    private RecyclerView rvHerramientas; //declaramos recycler

    //variables de recycler y adaptador
    private AdaptadorHerramientas adaptadorHerramientas;            //creamos clase boton derecho



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //iniciamos referencias
        initReferences();

        //configurar recycler
        configurarRecylerView();

        listaHerramientas=getListaHerramientas();



    }

    private void configurarRecylerView() {
        adaptadorHerramientas=new AdaptadorHerramientas((listaHerramientas));
        adaptadorHerramientas.setOnItemClickListener(new AdaptadorHerramientas.OnItemClickListener() {
            @Override
            public void onItemClick(int posicion) {
                //accion que queramos realizar y le pasamos la posicion
                lanzarSegundaPantalla(posicion);

            }
        });
        rvHerramientas.setAdapter(adaptadorHerramientas);
        rvHerramientas.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
    }

    private void lanzarSegundaPantalla(int posicion) {
        //PASAMOS LOS VALORES A LA SEGUNDA PANTALLA
        Intent iSegundaPantalla= new Intent(this,SegundaPantalla.class);
        iSegundaPantalla.putExtra(SegundaPantalla.EXTRA_POSICION,posicion);
        startActivity(iSegundaPantalla);

    }

    private void initReferences() {
        tvEncabezado=findViewById(R.id.tvEncabezado);
        rvHerramientas=findViewById(R.id.rvHerramientas);

    }
}