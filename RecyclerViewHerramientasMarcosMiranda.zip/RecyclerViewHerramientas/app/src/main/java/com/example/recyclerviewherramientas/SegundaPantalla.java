package com.example.recyclerviewherramientas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class SegundaPantalla extends AppCompatActivity {

    //declarar la posicion del item
    int pos=-1;
    //declaramos el objeto
    private Herramienta herramienta;

    //constante de la posicion
    public static final String EXTRA_POSICION="posicion";

    //declaramos vistas de la pantalla
    private TextView tvMarca,tvDenominacion,tvIdHerramienta;
    private ImageView ivHerramienta;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_pantalla);

        initReferences();

        //recojo la constante que viene de la pantalla principal
        if(getIntent().hasExtra(EXTRA_POSICION)){
            pos=getIntent().getIntExtra(EXTRA_POSICION,-1);
        } if(pos!=-1){
            herramienta=MainActivity.listaHerramientas.get(pos);
            mostrar(herramienta);

        }


    }

    private void mostrar(Herramienta herramienta) {
        ivHerramienta.setImageResource(herramienta.getIdImagen());
        tvMarca.setText(herramienta.getMarca());
        tvDenominacion.setText(herramienta.getDenominacion());
        tvIdHerramienta.setText(herramienta.getIdHerramienta());
    }

    private void initReferences() {
        tvMarca=findViewById(R.id.tvMarca);
        tvDenominacion=findViewById(R.id.tvDenominacion);
        tvIdHerramienta=findViewById(R.id.tvIdHerramienta);
        ivHerramienta=findViewById(R.id.ivHerramienta);

    }
}