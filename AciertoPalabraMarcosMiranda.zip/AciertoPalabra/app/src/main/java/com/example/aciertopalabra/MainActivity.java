package com.example.aciertopalabra;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    private ImageView ivLogo;
    private TextView tvTitulo, tvDescripcion, tvEscribePalabra, tvFondoPalabra, tvDetallePista;
    private CheckBox cbPista1, cbPista2, cbPista3, cbPista4;
    private Button botonComprobar;
    private EditText etPalabraApuesta, etPalabraSecreta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();

        listenersToCheckBoxes();

        botonComprobar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvFondoPalabra.setText(etPalabraApuesta.getText().toString());
                if (tvFondoPalabra.getText().toString().equals(etPalabraSecreta.getText().toString())) {
                    tvFondoPalabra.setBackgroundColor(Color.GREEN);
                } else {
                    tvFondoPalabra.setBackgroundColor(Color.RED);
                }

            }
        });


    }

    private void listenersToCheckBoxes() {
        cbPista1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    String opcion = etPalabraSecreta.getText().toString();
                    switch (opcion) {
                        case "perro":
                            String[] pistasPerros = getResources().getStringArray(R.array.pistas_perro);
                            tvDetallePista.setText(pistasPerros[0]);
                            break;
                        case "despertar":
                            String[] pistasDespertar = getResources().getStringArray(R.array.pistas_despertar);
                            tvDetallePista.setText(pistasDespertar[0]);
                            break;
                        case "pelota":
                            String[] pistasPelota = getResources().getStringArray(R.array.pistas_pelota);
                            tvDetallePista.setText(pistasPelota[0]);
                            break;
                    }
                } else {
                    tvDetallePista.setText("");
                }
            }
        });

        cbPista2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    String opcion = etPalabraSecreta.getText().toString();
                    switch (opcion) {
                        case "perro":
                            String[] pistasPerros = getResources().getStringArray(R.array.pistas_perro);
                            tvDetallePista.setText(pistasPerros[1]);
                            break;
                        case "despertar":
                            String[] pistasDespertar = getResources().getStringArray(R.array.pistas_despertar);
                            tvDetallePista.setText(pistasDespertar[1]);
                            break;
                        case "pelota":
                            String[] pistasPelota = getResources().getStringArray(R.array.pistas_pelota);
                            tvDetallePista.setText(pistasPelota[1]);
                            break;
                    }
                } else {
                    tvDetallePista.setText("");
                }
            }
        });
        cbPista3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    String opcion = etPalabraSecreta.getText().toString();
                    switch (opcion) {
                        case "perro":
                            String[] pistasPerros = getResources().getStringArray(R.array.pistas_perro);
                            tvDetallePista.setText(pistasPerros[2]);
                            break;
                        case "despertar":
                            String[] pistasDespertar = getResources().getStringArray(R.array.pistas_despertar);
                            tvDetallePista.setText(pistasDespertar[2]);
                            break;
                        case "pelota":
                            String[] pistasPelota = getResources().getStringArray(R.array.pistas_pelota);
                            tvDetallePista.setText(pistasPelota[2]);
                            break;
                    }
                } else {
                    tvDetallePista.setText("");
                }
            }
        });
        cbPista4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    String opcion = etPalabraSecreta.getText().toString();
                    switch (opcion) {
                        case "perro":
                            String[] pistasPerros = getResources().getStringArray(R.array.pistas_perro);
                            tvDetallePista.setText(pistasPerros[3]);
                            break;
                        case "despertar":
                            String[] pistasDespertar = getResources().getStringArray(R.array.pistas_despertar);
                            tvDetallePista.setText(pistasDespertar[3]);
                            break;
                        case "pelota":
                            String[] pistasPelota = getResources().getStringArray(R.array.pistas_pelota);
                            tvDetallePista.setText(pistasPelota[3]);
                            break;
                    }
                } else {
                    tvDetallePista.setText("");
                }
            }
        });
    }

    private void initReferences() {
        ivLogo = findViewById(R.id.ivLogo);
        tvTitulo = findViewById(R.id.tvTitulo);
        tvDescripcion = findViewById(R.id.tvDescripcion);
        tvEscribePalabra = findViewById(R.id.tvEscribePalabra);
        tvFondoPalabra = findViewById(R.id.tvFondoPalabra);
        tvDetallePista = findViewById(R.id.tvDetallePista);
        cbPista1 = findViewById(R.id.cbPista1);
        cbPista2 = findViewById(R.id.cbPista2);
        cbPista3 = findViewById(R.id.cbPista3);
        cbPista4 = findViewById(R.id.cbPista4);
        etPalabraApuesta = findViewById(R.id.etPalabraApuesta);
        etPalabraSecreta = findViewById(R.id.etPalabraSecreta);
        botonComprobar = findViewById(R.id.botonComprobar);

    }
}