package com.example.monumentos_marcos_miranda;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    //creamos la lista de monumentos para almacenarlos a partir de la clase Monumento creada.
    public static List<Monumento> listaMonumentos = new ArrayList<>();

    public List<Monumento> getListaMonumentos() {

        listaMonumentos.add(new Monumento("1", getString(R.string.nombreArco), getString(R.string.ubicacion1), 1553, getString(R.string.nombreArq1), getString(R.string.sexo1), getString(R.string.pais1), getString(R.string.descripcion1), true, getString(R.string.estilo1), 34, R.drawable.arco_santa_maria));
        listaMonumentos.add(new Monumento("2", getString(R.string.monumento2), getString(R.string.ubicacion2), 1221, getString(R.string.arquitecto2), getString(R.string.sexo2), getString(R.string.pais2), getString(R.string.descripcion2), true, getString(R.string.estilo2), 89, R.drawable.catedral_burgos));
        listaMonumentos.add(new Monumento("3", getString(R.string.monumento3), getString(R.string.ubicacion3), 1441, getString(R.string.arquitecto3), getString(R.string.sexo3), getString(R.string.pais3), getString(R.string.descripcion3), true, getString(R.string.estilo3), 89, R.drawable.cartuja));
        listaMonumentos.add(new Monumento("4", getString(R.string.monumento4), getString(R.string.ubicacion4), 1968, getString(R.string.arquitecto4), getString(R.string.sexo4), getString(R.string.pais4), getString(R.string.descripcion4), true, getString(R.string.estilo4), 24, R.drawable.cordon));
        listaMonumentos.add(new Monumento("5", getString(R.string.monumento5), getString(R.string.ubicacion5), 1955, getString(R.string.arquitecto5), getString(R.string.sexo5), getString(R.string.pais5), getString(R.string.descripcion5), false, getString(R.string.estilo5), 10, R.drawable.el_cid));
        listaMonumentos.add(new Monumento("6", getString(R.string.monumento6), getString(R.string.ubicacion6), 1181, getString(R.string.arquitecto6), getString(R.string.sexo6), getString(R.string.pais6), getString(R.string.descripcion6), false, getString(R.string.estilo6), 34, R.drawable.huelgas));
        return listaMonumentos;
    }


    //declaramos las vistas necesarias
    private TextView tvBienvenida, tvDescripcion, tvTitulo,tvEtiquetaNombre,tvDatoNombre,tvEtiquetaUbic,tvUbicacionDato,tvEtiquetaDescripcion;
    private ImageView ivMonumento,ivPortada;
    private Button botonOtro;

    private Button botonVerDetalles;

    // declaramos la constante para pasar dato a la segunda pantalla(activity)

    public final static String EXTRA_IMAGEN = "imagen";
    public final static String EXTRA_DESCRIPCION="descripcion";
    public final static String EXTRA_NOMBRE="nombre";
    public final static String EXTRA_UBICACION="ubicacion";
    public final static String EXTRA_CONSTRUCCION="construccion";
    public final static String EXTRA_ARQUITECTO="arquitecto";
    public final static String EXTRA_SEXO="sexo";
    public final static String EXTRA_PAIS="pais";
    public final static String EXTRA_PATRIM="patrim";
    public final static String EXTRA_ESTILO="estilo";



    // variable que recogeré el valor del random
    int numero;

    // declaramos el lanzador, launcher siempre antes del onCreate
    private ActivityResultLauncher<Intent> launcherPantallaDetalle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //iniciamos referencias de las vistas
        initReferences();

        //inicializamos en el OnCreate la lista de monumentos
        listaMonumentos = getListaMonumentos();

        //lanzamos el random
        hacerRandom();

        // registramos el launcher

        launcherPantallaDetalle=registroDevolucionPantallaDetalle();

        // accion del boton verDetalles.... lanzará a la segunda activity
        botonVerDetalles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lanzarPantallaDetalle();
            }
        });

        // boton que cambia el monumento que se esta visualizando en la pantalla principal
        botonOtro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero = hacerRandom();
            }
        });




    }

    private ActivityResultLauncher<Intent> registroDevolucionPantallaDetalle() {
        return registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        //codigo que se ejecuta cuando la segunda activity devuelve el control a esta
                        if(result.getResultCode()==RESULT_OK){
                            Intent data=result.getData();
                            completarDatos(data);
                        }
                    }
                }
        );
    }

    private void completarDatos(Intent data) {
        tvDatoNombre.setText(data.getStringExtra(PantallaDetalle.EXTRA_NOMBRE));
        numero=data.getIntExtra(PantallaDetalle.EXTRA_NUMERO_IMAGEN,0);
        listaMonumentos.get(numero).setNombre(String.valueOf(tvDatoNombre.getText().toString()));
        tvUbicacionDato.setText(data.getStringExtra(PantallaDetalle.EXTRA_UBICACION));
        listaMonumentos.get(numero).setUbicacion(tvUbicacionDato.getText().toString());
        tvDescripcion.setText(data.getStringExtra(PantallaDetalle.EXTRA_DESCRIPCION));
        listaMonumentos.get(numero).setDescripcion(tvDescripcion.getText().toString());

    }


    // metodo privado que lanza la otra pantalla de detalle
    private void lanzarPantallaDetalle() {
        Intent iPantallaDetalle = new Intent(this, PantallaDetalle.class);

        // tomamos los textos a pasar
        String nombre=tvDatoNombre.getText().toString();
        String ubicacion=tvUbicacionDato.getText().toString();
        String descripcion=tvDescripcion.getText().toString();
        String sexo=listaMonumentos.get(numero).getArquitecto().getSexo();
        String pais=listaMonumentos.get(numero).getArquitecto().getPais();
        String estilo=listaMonumentos.get(numero).getEstiloArquitectonico();
        String patrimonio= String.valueOf(listaMonumentos.get(numero).isPatrimonioMundial());
        String arquitecto=listaMonumentos.get(numero).getArquitecto().getNombre();
        String anioConst= String.valueOf(listaMonumentos.get(numero).getAnoFabricacion());

        //creamos Bundle para pasar grupo de constantes
        Bundle bundle = new Bundle();

        bundle.putString(EXTRA_NOMBRE,nombre);
        bundle.putString(EXTRA_UBICACION,ubicacion);
        bundle.putString(EXTRA_DESCRIPCION,descripcion);
        bundle.putInt(EXTRA_IMAGEN, numero);
        bundle.putInt(EXTRA_CONSTRUCCION, Integer.parseInt(anioConst));
        bundle.putString(EXTRA_ARQUITECTO,arquitecto);
        bundle.putString(EXTRA_SEXO,sexo);
        bundle.putString(EXTRA_PAIS,pais);
        bundle.putString(EXTRA_PATRIM,patrimonio);
        bundle.putString(EXTRA_ESTILO,estilo);


        iPantallaDetalle.putExtras(bundle);

        launcherPantallaDetalle.launch(iPantallaDetalle);


    }


    //hacemos el random para que salga la imagen y su descripcion
    private int hacerRandom() {
        Random random = new Random();
        int numero = random.nextInt(6);
        switch (numero) {
            case 0:
                ivMonumento.setImageResource(listaMonumentos.get(0).getFotoId());
                tvDescripcion.setText(listaMonumentos.get(0).getDescripcion());
                tvUbicacionDato.setText(listaMonumentos.get(0).getUbicacion());
                tvDatoNombre.setText(listaMonumentos.get(0).getNombre());

                break;

            case 1:
                ivMonumento.setImageResource(listaMonumentos.get(1).getFotoId());
                tvDescripcion.setText(listaMonumentos.get(1).getDescripcion());
                tvUbicacionDato.setText(listaMonumentos.get(1).getUbicacion());
                tvDatoNombre.setText(listaMonumentos.get(1).getNombre());

                break;

            case 2:
                ivMonumento.setImageResource(listaMonumentos.get(2).getFotoId());
                tvDescripcion.setText(listaMonumentos.get(2).getDescripcion());
                tvUbicacionDato.setText(listaMonumentos.get(2).getUbicacion());
                tvDatoNombre.setText(listaMonumentos.get(2).getNombre());

                break;

            case 3:
                ivMonumento.setImageResource(listaMonumentos.get(3).getFotoId());
                tvDescripcion.setText(listaMonumentos.get(3).getDescripcion());
                tvUbicacionDato.setText(listaMonumentos.get(3).getUbicacion());
                tvDatoNombre.setText(listaMonumentos.get(3).getNombre());

                break;

            case 4:
                ivMonumento.setImageResource(listaMonumentos.get(4).getFotoId());
                tvDescripcion.setText(listaMonumentos.get(4).getDescripcion());
                tvUbicacionDato.setText(listaMonumentos.get(4).getUbicacion());
                tvDatoNombre.setText(listaMonumentos.get(4).getNombre());

                break;
            case 5:
                ivMonumento.setImageResource(listaMonumentos.get(5).getFotoId());
                tvDescripcion.setText(listaMonumentos.get(5).getDescripcion());
                tvUbicacionDato.setText(listaMonumentos.get(5).getUbicacion());
                tvDatoNombre.setText(listaMonumentos.get(5).getNombre());

                break;

        }

        return numero;
    }


    //metodo privado que inicializa las vistas xml

    private void initReferences() {
        tvTitulo = findViewById(R.id.tvTitulo);
        tvBienvenida = findViewById(R.id.tvBienvenida);
        tvDescripcion = findViewById(R.id.tvDescripcion);
        botonVerDetalles = findViewById(R.id.botonDetalles);
        botonOtro = findViewById(R.id.botonOtro);
        ivMonumento = findViewById(R.id.ivMonumento);
        tvEtiquetaNombre=findViewById(R.id.tvEtiquetaNombre);
        tvDatoNombre=findViewById(R.id.tvDatoNombre);
        tvEtiquetaUbic=findViewById(R.id.tvEtiquetaUbic);
        tvEtiquetaDescripcion=findViewById(R.id.tvEtiquetaDescripcion);
        ivPortada=findViewById(R.id.ivPortada);
        tvUbicacionDato=findViewById(R.id.tvUbicacionDato);
    }

    /**
     * metodo para guardar datos cambio pantalla
     * @param savedInstanceState Bundle in which to place your saved state.
     *
     */
    @Override
    protected void onSaveInstanceState( Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString(EXTRA_DESCRIPCION,tvDescripcion.getText().toString());
        savedInstanceState.putString(EXTRA_NOMBRE,tvDatoNombre.getText().toString());
        savedInstanceState.putString(EXTRA_UBICACION,tvUbicacionDato.getText().toString());
        savedInstanceState.putInt(EXTRA_IMAGEN,numero);

    }

    /**
     * metodo que recupera los datos cambio pantalla
     * @param savedInstanceState the data most recently supplied in {@link #onSaveInstanceState}.
     *
     */
    @Override
    protected void onRestoreInstanceState( Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        tvDescripcion.setText(savedInstanceState.getString(EXTRA_DESCRIPCION));
        tvDatoNombre.setText(savedInstanceState.getString(EXTRA_NOMBRE));
        tvUbicacionDato.setText(savedInstanceState.getString(EXTRA_UBICACION));
        numero=savedInstanceState.getInt(EXTRA_IMAGEN,0);
        ivMonumento.setImageResource((listaMonumentos.get(numero).getFotoId()));

    }


}