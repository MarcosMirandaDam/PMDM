package com.example.monumentos_marcos_miranda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class PantallaDetalle extends AppCompatActivity implements View.OnClickListener {

    //creamos las variables
    ImageView ivMonumento;
    EditText etDescripcion, etDatoNombre, etUbicacion, etNombreArquitecto, etAnioConstruccion, etSexo, etPais, etPatrimonio, etEstilo;
    int numero;

    TextView tvAplicarCambios, tvNombreMonum;

    Button botonGrabar, botonCancelar;

    //constantes para devolver a la primera pantalla
    public static final String EXTRA_NUMERO_IMAGEN = "imagen";
    public static final String EXTRA_UBICACION="ubicacion";
    public static final String EXTRA_DESCRIPCION="descripcion";
    public static final String EXTRA_NOMBRE="nombre";




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_detalle);

        initReferences();

        //recuperar los datos de la activity principal

        Intent i = getIntent();
        //comprobamos que existe el intent y que existe las constantes declaradas para recuperar los datos

        Bundle bundle = i.getExtras();


        int numeroImagen = i.getIntExtra(MainActivity.EXTRA_IMAGEN, 0);
        numero = numeroImagen;
        pasarFoto(numeroImagen);
        String nombre = i.getStringExtra(MainActivity.EXTRA_NOMBRE);
        etDatoNombre.setText(nombre);
        String ubic = i.getStringExtra(MainActivity.EXTRA_UBICACION);
        etUbicacion.setText(ubic);
        String descripcion = i.getStringExtra(MainActivity.EXTRA_DESCRIPCION);
        etDescripcion.setText(descripcion);
        String sexo = i.getStringExtra(MainActivity.EXTRA_SEXO);
        etSexo.setText(sexo);
        String pais = i.getStringExtra(MainActivity.EXTRA_PAIS);
        etPais.setText(pais);
        String patrimonio = i.getStringExtra(MainActivity.EXTRA_PATRIM);
        if (patrimonio.equals("true")) {
            etPatrimonio.setText("SI");
        } else {
            etPatrimonio.setText("NO");
        }
        String estilo = i.getStringExtra(MainActivity.EXTRA_ESTILO);
        etEstilo.setText(estilo);
        String arquitecto = i.getStringExtra(MainActivity.EXTRA_ARQUITECTO);
        etNombreArquitecto.setText(arquitecto);
        String anioConst = String.valueOf(i.getIntExtra(MainActivity.EXTRA_CONSTRUCCION, 0));
        etAnioConstruccion.setText(anioConst);

        //hacemos listener para los botones creados GRABAR Y CANCELAR
        setListenersToButtons();
    }

    private void initReferences() {
        tvNombreMonum = findViewById(R.id.tvNombreMonum);
        etDescripcion = findViewById(R.id.etDescripcion);
        ivMonumento = findViewById(R.id.ivMonumento);
        botonGrabar = findViewById(R.id.botonGrabar);
        botonCancelar = findViewById(R.id.botonCancelar);
        tvAplicarCambios = findViewById(R.id.tvAplicarCambios);
        etDatoNombre = findViewById(R.id.etDatoNombre);
        etEstilo = findViewById(R.id.etEstilo);
        etSexo = findViewById(R.id.etSexo);
        etPais = findViewById(R.id.etPais);
        etUbicacion = findViewById(R.id.etUbicacion);
        etPatrimonio = findViewById(R.id.etPatrimonio);
        etNombreArquitecto = findViewById(R.id.etNombreArquitecto);
        etAnioConstruccion = findViewById(R.id.etAnioConstruccion);

    }

    private void setListenersToButtons() {
        botonGrabar.setOnClickListener(this);
        botonCancelar.setOnClickListener(this);
    }


    // establecemos texto, imagen y titulo de cada monumento
    private void pasarFoto(int i) {
        switch (i) {
            case 0:
                ivMonumento.setImageResource(MainActivity.listaMonumentos.get(0).getFotoId());

                break;
            case 1:
                ivMonumento.setImageResource(MainActivity.listaMonumentos.get(1).getFotoId());
                break;
            case 2:
                ivMonumento.setImageResource(MainActivity.listaMonumentos.get(2).getFotoId());
                break;
            case 3:
                ivMonumento.setImageResource(MainActivity.listaMonumentos.get(3).getFotoId());
                break;
            case 4:
                ivMonumento.setImageResource(MainActivity.listaMonumentos.get(4).getFotoId());
                break;
            case 5:
                ivMonumento.setImageResource(MainActivity.listaMonumentos.get(5).getFotoId());
                break;

        }
    }


    @Override
    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.botonCancelar) {
            finish();
        } else {
            String nombreModificado = etDatoNombre.getText().toString();
            String ubicacionModificada = etUbicacion.getText().toString();
            String descripcionModificada = etDescripcion.getText().toString();
            Intent resultIntent=new Intent();
            resultIntent.putExtra(EXTRA_NOMBRE,nombreModificado);
            resultIntent.putExtra(EXTRA_UBICACION,ubicacionModificada);
            resultIntent.putExtra(EXTRA_DESCRIPCION,descripcionModificada);
            resultIntent.putExtra(EXTRA_NUMERO_IMAGEN,numero);
            setResult(RESULT_OK,resultIntent);
            finish();
        }

    }
}
