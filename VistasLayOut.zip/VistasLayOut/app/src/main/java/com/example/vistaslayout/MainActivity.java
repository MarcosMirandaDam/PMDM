package com.example.vistaslayout;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.app.Activity;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    //declaramos las variables
    private TextView tvTitulo;
    private CheckBox cbRojo, cbTransparente, cbVerde;
    private ImageView ivImagen;
    private RadioGroup radioGroup;
    private RadioButton rbCentrado, rbEstirado;
    private ImageButton ibMortadelo, ibMafalda;

    // declaramos posibles constantes para almacenar datos a pasar segunda activity

    // declaramos el lanzador, launcher siempre antes del onCreate

    //variables para utilizar


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();

        ajustarImagen();

        setListenersToButtons();

        establecerFondo();

    }

    private void establecerFondo() {
        cbRojo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    ivImagen.setBackgroundColor(Color.RED);
                } else {
                    ivImagen.setBackgroundColor(Color.TRANSPARENT);
                }
            }
        });

        cbTransparente.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    ivImagen.getDrawable().setAlpha(128);
                } else {
                    ivImagen.getDrawable().setAlpha(255);
                }
            }
        });

        cbVerde.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    getWindow().getDecorView().setBackgroundColor(Color.GREEN);
                } else {
                    getWindow().getDecorView().setBackgroundColor(Color.WHITE);
                }

            }
        });

    }

    private void setListenersToButtons() {
        ibMafalda.setOnClickListener(this::onClick);
        ibMortadelo.setOnClickListener(this::onClick);

    }

    private void onClick(View view) {
        int id = view.getId();
        if (id == R.id.ibMortadelo) {
            ivImagen.setImageDrawable(ibMortadelo.getDrawable());
        }
        if (id == R.id.ibMafalda)
            ivImagen.setImageDrawable(ibMafalda.getDrawable());

    }

    private void ajustarImagen() {
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                //recoger el radio marcado
                int idRadiobuttonElegido = radioGroup.getCheckedRadioButtonId();
                if (idRadiobuttonElegido == R.id.rbCentrado) {
                    ivImagen.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
                }
                if (idRadiobuttonElegido == R.id.rbEstirado) {
                    ivImagen.setScaleType(ImageView.ScaleType.CENTER_CROP);
                }
                if (idRadiobuttonElegido == -1) {
                    ivImagen.setScaleType(ImageView.ScaleType.FIT_CENTER);
                }
            }
        });

    }


    private void initReferences() {
        tvTitulo = findViewById(R.id.tvTitulo);
        cbRojo = findViewById(R.id.cbRojo);
        cbTransparente = findViewById(R.id.cbTransparente);
        cbVerde = findViewById(R.id.cbVerde);
        ivImagen = findViewById(R.id.ivImagen);
        radioGroup = findViewById(R.id.radioGroup);
        rbCentrado = findViewById(R.id.rbCentrado);
        rbEstirado = findViewById(R.id.rbEstirado);
        ibMortadelo = findViewById(R.id.ibMortadelo);
        ibMafalda = findViewById(R.id.ibMafalda);

    }
}