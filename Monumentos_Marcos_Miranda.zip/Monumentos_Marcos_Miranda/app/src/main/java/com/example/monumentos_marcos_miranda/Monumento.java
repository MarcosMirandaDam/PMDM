package com.example.monumentos_marcos_miranda;

import android.graphics.Bitmap;

public class Monumento {

    private int idMonumento;
    private String nombre;
    private String ubicacion;
    private int anoFabricacion;
    private String arquitecto;
    private String descripcion;
    private boolean patrimonioMundial;
    private String estiloArquitectonico;
    private int altura;

       public Monumento(int idMonumento,String nombre, String ubicacion, int anoFabricacion, String arquitecto, String descripcion, boolean patrimonioMundial, String estiloArquitectonico, int altura) {
        this.idMonumento=idMonumento;
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.anoFabricacion = anoFabricacion;
        this.arquitecto = arquitecto;
        this.descripcion = descripcion;
        this.patrimonioMundial = patrimonioMundial;
        this.estiloArquitectonico = estiloArquitectonico;
        this.altura = altura;

    }

    public int getIdMonumento() {
        return idMonumento;
    }

    public void setIdMonumento(int idMonumento) {
        this.idMonumento = idMonumento;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public int getAnoFabricacion() {
        return anoFabricacion;
    }

    public void setAnoFabricacion(int anoFabricacion) {
        this.anoFabricacion = anoFabricacion;
    }

    public String getArquitecto() {
        return arquitecto;
    }

    public void setArquitecto(String arquitecto) {
        this.arquitecto = arquitecto;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public boolean isPatrimonioMundial() {
        return patrimonioMundial;
    }

    public void setPatrimonioMundial(boolean patrimonioMundial) {
        this.patrimonioMundial = patrimonioMundial;
    }

    public String getEstiloArquitectonico() {
        return estiloArquitectonico;
    }

    public void setEstiloArquitectonico(String estiloArquitectonico) {
        this.estiloArquitectonico = estiloArquitectonico;
    }

    public int getAltura() {
        return altura;
    }

    public void setAltura(int altura) {
        this.altura = altura;
    }





    public String toStringCorto() {
        return "" +
                "Nombre:"+nombre+ "\n" +
                "Ubicacion:"+ubicacion+ "\n" +
                "Descripcion:"+descripcion+ "";
    }

    public String toStringDetalleCompleto() {
        return "" +
                "Nombre:" +nombre+ "\n" +
                "Ubicacion:"+ubicacion+ "\n" +
                "Año de Fabricacion:"+anoFabricacion+ "\n" +
                "Arquitecto:"+arquitecto+ "\n" +
                "Descripcion:"+descripcion+ "\n" +
                "Patrimonio Mundial:"+patrimonioMundial+ "\n" +
                "Estilo Arquitectonico:"+estiloArquitectonico+ "\n" +
                "Altura:"+altura+ " metros" +
                "";
    }
}
