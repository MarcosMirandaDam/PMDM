package com.example.monumentos_marcos_miranda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    TextView tvBienvenida,tvDescripcion;

    Button botonOtro;

    private Button botonVerDetalles;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();

        tvBienvenida.setText("Historia, cultura y belleza recorren las calles de Burgos. " +
                "Paseos increíbles que te envolverán en su ambiente, y te transportarán a lo largo de acontecimientos " +
                "históricos y épocas lejanas. Una ciudad para descubrir, en todas sus vertientes y con todos los sentidos. " +
                "No tenemos duda de que los monumentos de Burgos son únicos e inigualables, con un encanto especial digno " +
                "de descubrir por turistas y redescubrir por quienes son tan afortunados de poder vivir en esta maravillosa " +
                "ciudad. Para que no te pierdas ningún imprescindible, te dejamos nuestra selección para que las visitas y " +
                "los paseos por Burgos sean más que completos. ¡Sumérgete en todos sus rincones!");

        tvDescripcion.setText("Probando a añadir texto");

        botonVerDetalles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lanzarPantallaDetalle();
            }
        });
    }

    // metodo privado que lanza la otra pantalla de detalle
    private void lanzarPantallaDetalle(){
        Intent iPantallaDetalle=new Intent(this, PantallaDetalle.class);

        String texto="";
        if(tvDescripcion.getText().length()!=0){
            texto=tvDescripcion.getText().toString();

        }
        iPantallaDetalle.putExtra("",texto);

        startActivity(iPantallaDetalle);

    }

    //metodo privado que inicializa las vistas xml
    private void initReferences(){
        tvBienvenida=findViewById(R.id.tvBienvenida);
        tvDescripcion=findViewById(R.id.tvDescripcion);
        botonVerDetalles=findViewById(R.id.botonDetalles);
        botonOtro=findViewById(R.id.botonOtro);
    }



}