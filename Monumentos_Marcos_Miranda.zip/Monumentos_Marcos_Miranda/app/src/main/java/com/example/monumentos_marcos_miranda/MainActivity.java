package com.example.monumentos_marcos_miranda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    //lista de monumentos
    List<Monumento> listaMonumentos = new ArrayList<>();              //creamos lista de monumentos
    //array de imagenes para entrar en ellas aleatoriamente
    String[] imagenes={"cartuja","arco_santa_maria","catedral_burgos","el_cid","huelgas","cordon"};     //array de imagenes
    //hacemos el random para las imagenes
    Random random=new Random();
    Monumento monumento1 = new Monumento(1, "Arco Santa Maria", "España, Burgos", 1553, "Francisco de Colonia", "El Arco de Santa María es uno de los monumentos más visitados y emblemáticos de la ciudad de Burgos.", true, "Renacenista", 24);
    Monumento monumento2 = new Monumento(2, "Catedral Sta.María", "España, Burgos", 1221, "Marcos Miranda", "La Santa Iglesia Catedral Basílica Metropolitana de Santa María es un templo catedralicio de culto católico dedicado a la Virgen María, en la ciudad española de Burgos. Pertenece a la archidiócesis de Burgos.", true, "Gotico", 24);
    Monumento monumento3 = new Monumento(3, "Cartuja Miraflores", "España, Burgos", 1441, "Juan de Colonia", "La Cartuja de Santa María de Miraflores es un monasterio de la Orden de los Cartujos, edificado en una loma conocida como Miraflores, situada a unos tres kilómetros del centro de la ciudad de Burgos. Es una joya del arte gótico final", true, "Gotico", 24);
    Monumento monumento4 = new Monumento(4, "Casa Cordón", "España, Burgos", 1968, "Juan de Colonia", "El palacio de los Condestables de Castilla, conocido popularmente como casa del Cordón, es un palacio originario del siglo XV que se alza en el casco histórico de Burgos, presidiendo la antigua plaza del Mercado Mayor, que estaba formada por las actuales plazas de La Libertad y Santo Domingo de Guzmán", true, "Gotico", 24);
    Monumento monumento5 = new Monumento(5, "El Cid", "España, Burgos", 1955, "Fernando Chueca Goitia", "El Monumento al Cid Campeador es una estatua ecuestre situada en la ciudad de Burgos, en España, y representa a Rodrigo Díaz de Vivar, un líder militar castellano que llegó a dominar al frente de su propia mesnada el Levante de la península ibérica a finales del siglo XI", true, "Gotico", 10);
    Monumento monumento6 = new Monumento(6, "Monasterio Las Huelgas", "España, Burgos", 1181, "", "El monasterio de Santa María la Real de las Huelgas, conocido popularmente como monasterio de las Huelgas, \u200B situado en la ciudad de Burgos, es un monasterio de la congregación de monasterios de monjas cistercienses de San Bernardo", true, "Cisterciense", 24);

    public List<Monumento> listaMonumentos() {
        listaMonumentos.add(monumento1);
        listaMonumentos.add(monumento2);
        listaMonumentos.add(monumento3);
        listaMonumentos.add(monumento4);
        listaMonumentos.add(monumento5);
        listaMonumentos.add(monumento6);

        return listaMonumentos;
    }

    TextView tvBienvenida, tvDescripcion;
    ImageView ivMonumento;
    Button botonOtro;

    private Button botonVerDetalles;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();
        tvBienvenida.setText(textoBienvenida());

        int randomIndice=random.nextInt(imagenes.length);
        int resourceId=getResources().getIdentifier(imagenes[randomIndice],"drawable",getPackageName());
        ivMonumento.setImageResource(resourceId);           //asi cargamos la foto del monumento

        tvDescripcion.setText(monumento1.toStringCorto());

        botonVerDetalles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lanzarPantallaDetalle();
            }
        });

        // boton que cambia el monumento que se esta visualizando en la pantalla principal
        botonOtro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int randomIndice=random.nextInt(imagenes.length);
                int resourceId=getResources().getIdentifier(imagenes[randomIndice],"drawable",getPackageName());
                ivMonumento.setImageResource(resourceId);           //asi cargamos la foto del monumento
            }
        });

    }

    // metodo privado que lanza la otra pantalla de detalle
    private void lanzarPantallaDetalle() {
        Intent iPantallaDetalle = new Intent(this, PantallaDetalle.class);

        // pasamos el texto
        String texto = "";
        texto = monumento1.toStringDetalleCompleto();


        iPantallaDetalle.putExtra("", texto);

        startActivity(iPantallaDetalle);

    }

    //metodo que establece el texto de bienvenida de la app
    private String textoBienvenida() {
        String texto;
        texto = ("Historia, cultura y belleza recorren las calles de Burgos. " +
                "Paseos increíbles que te envolverán en su ambiente, y te transportarán a lo largo de acontecimientos " +
                "históricos y épocas lejanas. Una ciudad para descubrir, en todas sus vertientes y con todos los sentidos. " +
                "No tenemos duda de que los monumentos de Burgos son únicos e inigualables, con un encanto especial digno " +
                "de descubrir por turistas y redescubrir por quienes son tan afortunados de poder vivir en esta maravillosa " +
                "ciudad. Para que no te pierdas ningún imprescindible, te dejamos nuestra selección para que las visitas y " +
                "los paseos por Burgos sean más que completos. ¡Sumérgete en todos sus rincones!");
        return texto;
    }



    //metodo privado que inicializa las vistas xml
    private void initReferences(){
        tvBienvenida=findViewById(R.id.tvBienvenida);
        tvDescripcion=findViewById(R.id.tvDescripcion);
        botonVerDetalles=findViewById(R.id.botonDetalles);
        botonOtro=findViewById(R.id.botonOtro);
        ivMonumento=findViewById(R.id.ivMonumento);
    }



}