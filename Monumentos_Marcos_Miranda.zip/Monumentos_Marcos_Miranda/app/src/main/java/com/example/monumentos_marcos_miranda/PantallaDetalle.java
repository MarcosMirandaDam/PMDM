package com.example.monumentos_marcos_miranda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class PantallaDetalle extends AppCompatActivity {

    ImageView iv2;

    TextView tv2;
    String texto="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_detalle);

        tv2=findViewById(R.id.tv2);


        //recuperar los datos de la activity principal

        Intent i=getIntent();
        if(i.hasExtra(texto)){
            texto=i.getStringExtra(texto);
            tv2.setText(texto);
        }

    }

}