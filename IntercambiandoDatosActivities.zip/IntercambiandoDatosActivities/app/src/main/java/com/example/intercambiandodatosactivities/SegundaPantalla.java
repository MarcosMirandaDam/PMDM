package com.example.intercambiandodatosactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SegundaPantalla extends AppCompatActivity {

    private TextView tvDatoRecibido;
    private Button botonMayusculas,botonCancelar;

    //variable para traer el dato de la primera pantalla
    String datoRecibido;

    //constante para pasar a la pantalla principal
    public static final String EXTRA_DATO="dato_Mayusculas";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_pantalla);

        initReferences();

        //recuperamos los datos recibidos de la primera pantalla y pintamos tvDatoRecibido
        Intent i=getIntent();

        if(i.hasExtra(MainActivity.EXTRA_DATO_PASAR)){
          datoRecibido=i.getStringExtra(MainActivity.EXTRA_DATO_PASAR);
          tvDatoRecibido.setText(datoRecibido);
        }

        //llamada a los botones
        setListenerToButtons();


    }

    /**
     * escuchadores de los botones
     */
    private void setListenerToButtons() {
        botonCancelar.setOnClickListener(this::onClick);
        botonMayusculas.setOnClickListener(this::onClick);
    }

    /**
     * metodo onClick de los botones
     * @param view
     */
    private void onClick(View view) {
        int id = view.getId();
        if (id == R.id.botonCancelar) {
            finish();
        } else {
            String datoRecibido=tvDatoRecibido.getText().toString();
            datoRecibido=pasarDatoMayusculas(datoRecibido);
            Intent resultIntent=new Intent();
            resultIntent.putExtra(EXTRA_DATO,datoRecibido);
            setResult(RESULT_OK,resultIntent);
            finish();
        }
    }

    /**
     * metodo que pasa a mayusculas el dato recibido
     *
     * @return
     */
    private String pasarDatoMayusculas(String datoRecibido){
        String dato = tvDatoRecibido.getText().toString();
        dato = dato.toUpperCase();
        return dato;
    }

    /**
     * iniciamos las vistas
     */
    private void initReferences() {
        tvDatoRecibido=findViewById(R.id.tvDatoRecibido);
        botonMayusculas=findViewById(R.id.botonMayusculas);
        botonCancelar=findViewById(R.id.botonCancelar);
    }
}