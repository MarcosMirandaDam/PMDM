package com.example.intercambiandodatosactivities;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //declaramos las variables
    private TextView tvDatoResultante;
    private EditText etDatoPasar;
    // constante para intercambiar entre activity
    public final static String EXTRA_DATO_PASAR="datoPasar";

    private Button botonPasar;

    // declaramos el lanzador siempre antes del onCreate
    private ActivityResultLauncher<Intent> launcher;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();

        //registramos el lanzador
        launcher=registroDevolucionDato();

        //listener de los botones, en este caso del unico boton
        setListenersToButtons();


    }

    /**
     * metodo setOnClick del boton pasar
     */
    private void setListenersToButtons() {
        botonPasar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lanzarSegundaPantallaActivity();
            }
        });
    }

    /**
     * metodo que lanza la segunda pantalla con el launcher incluido
     */
    private void lanzarSegundaPantallaActivity() {
        //pasamos el valor del dato a la segunda pantalla
        String dato = etDatoPasar.getText().toString();
        if (dato.isEmpty()) {
            etDatoPasar.setError(getString(R.string.error_debes_escribir_algo));
        } else {
            Intent iSegundaPantalla = new Intent(this, SegundaPantalla.class);
            iSegundaPantalla.putExtra(EXTRA_DATO_PASAR, dato);
            launcher.launch(iSegundaPantalla);
        }
    }

    /**
     * metodo que rgistra la devolucion de llamada de resultados provenientes de la otra activity
     * @return
     */
    private ActivityResultLauncher<Intent> registroDevolucionDato() {
        return registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if(result.getResultCode()==RESULT_OK){
                            Intent data=result.getData();
                            completarCampos(data);
                        }
                    }
                }
        );
    }

    /**
     * metodo que pinta los datos traidos de la segunda pantalla
     * @param data
     */
    private void completarCampos(Intent data) {
        tvDatoResultante.setText(data.getStringExtra(SegundaPantalla.EXTRA_DATO));
    }

    /**
     * metodo que inicia las vistas
     */
    private void initReferences() {
        botonPasar=findViewById(R.id.botonPasar);
        etDatoPasar=findViewById(R.id.etDatoPasar);
        tvDatoResultante=findViewById(R.id.tvDatoResultante);

    }
}