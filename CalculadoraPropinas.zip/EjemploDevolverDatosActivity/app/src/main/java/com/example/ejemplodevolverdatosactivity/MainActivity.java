package com.example.ejemplodevolverdatosactivity;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //declaramos las variables
    private TextView tvTitulo, tvImporte, tvSimboloMoneda, tvPropinaEtiqueta, tvValorPropina, tvTotalPagarEtiqueta, tvTotalPagar;
    private EditText editTextImporteSinPropina;

    private Button botonCalcularPropina;


    //declaramos la constante necesaria para almacenar el importe
    public final static String EXTRA_IMPORTE_SIN_PROPINA = "importeSinPropina";

    //declaramos el lanzador, launcher siempre antes del ONCREATE
    private ActivityResultLauncher<Intent> launcherCalcularPropinaActivity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();

        setListenersToButtons();

        //registro el lanzador
        launcherCalcularPropinaActivity = registroDevolucionCalcularPropina();


    }

    /**
     * metodo que registra la devolucion de llamada de resultados provenientes de otra activity
     *
     * @return
     */
    private ActivityResultLauncher<Intent> registroDevolucionCalcularPropina() {
        return registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        //codigo que se ejecuta cuando la segunda activity devuelve control a esta
                        if (result.getResultCode() == RESULT_OK) {
                            Bundle datos = result.getData().getExtras();
                            completarDatos(datos);
                        }
                    }
                }
        );
    }



    private void setListenersToButtons() {

        botonCalcularPropina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                lanzarCalcularPropinaActivity();
            }
        });
    }


    private void lanzarCalcularPropinaActivity() {

        //pasamos el valor del importe sin propina a la segunda activity
        String importe = editTextImporteSinPropina.getText().toString();
        if (importe.isEmpty()) {
            editTextImporteSinPropina.setError(getString(R.string.error_debes_introducir_un_importe));
        } else {
            Intent iPantallaCalcularPropina = new Intent(this, CalcularPropinaActivity.class);
            iPantallaCalcularPropina.putExtra(EXTRA_IMPORTE_SIN_PROPINA, Double.parseDouble(importe));
            launcherCalcularPropinaActivity.launch(iPantallaCalcularPropina);

        }


    }
    private void completarDatos(Bundle datos) {
        tvValorPropina.setText(String.valueOf(datos.getDouble(CalcularPropinaActivity.EXTRA_PROPINA)));
        tvTotalPagar.setText(String.valueOf(datos.getDouble(CalcularPropinaActivity.EXTRA_RESULTADO_TOTAL_PAGAR)));

    }

    private void initReferences() {
        tvTitulo = findViewById(R.id.tvTitulo);
        tvImporte = findViewById(R.id.tvImporte);
        tvSimboloMoneda = findViewById(R.id.tvSimboloMoneda);
        tvPropinaEtiqueta = findViewById(R.id.tvPropinaEtiqueta);
        tvValorPropina = findViewById(R.id.tvValorPropina);
        tvTotalPagarEtiqueta = findViewById(R.id.tvTotalPagarEtiqueta);
        tvTotalPagar = findViewById(R.id.tvTotalPagar);
        editTextImporteSinPropina = findViewById(R.id.etValorImporteSinPropina);
        botonCalcularPropina = findViewById(R.id.botonPropina);
    }
}