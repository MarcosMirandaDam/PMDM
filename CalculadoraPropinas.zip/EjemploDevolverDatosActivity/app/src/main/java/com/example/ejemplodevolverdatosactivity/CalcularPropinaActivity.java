package com.example.ejemplodevolverdatosactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class CalcularPropinaActivity extends AppCompatActivity {

    //declaramos constantes
    public static final String EXTRA_PROPINA = "valorPropina";
    public static final String EXTRA_RESULTADO_TOTAL_PAGAR = "totalPagar";

    //declaramos las variables a utilizar.
    private TextView tvImporteRecibido;
    private Button botonCalcular, botonCancelar;

    private RadioGroup radioGroup;
    private RadioButton radioButton15, radioButton20, radioButton18;


    double importeSinPropina;       //para recoger el dato de la primera pantalla
    int porcentaje;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calcular_propina);

        initReferences();

        //recuperamos los datos de la primera activity y pintamos el campo tvImporteSinPropina
        Intent i = getIntent();

        if (i.hasExtra(MainActivity.EXTRA_IMPORTE_SIN_PROPINA)) {
            importeSinPropina = (i.getDoubleExtra(MainActivity.EXTRA_IMPORTE_SIN_PROPINA, 0));
            tvImporteRecibido.setText(String.valueOf(importeSinPropina));

        }
        setListenerToButtons();


    }

    private void setListenerToButtons() {
        botonCalcular.setOnClickListener(this::onClick);
        botonCancelar.setOnClickListener(this::onClick);
    }


    public void onClick(View view) {
        int id = view.getId();
        if (id == R.id.botonCancelar) {
            finish();
        } else {
            Bundle infoPropinaDevolver = calcularPropina(importeSinPropina);
            Intent resultIntent = new Intent();
            resultIntent.putExtras(infoPropinaDevolver);
            setResult(RESULT_OK, resultIntent);
            finish();
        }
    }

    private void initReferences() {
        // declaramos las vistas de las variables instanciadas arriba
        tvImporteRecibido = findViewById(R.id.etValorImporteSinPropina);
        radioGroup = findViewById(R.id.radioGroup);
        radioButton15 = findViewById(R.id.radioButton15);
        radioButton20 = findViewById(R.id.radioButton20);
        radioButton18 = findViewById(R.id.radioButton18);
        botonCalcular = findViewById(R.id.botonCalcular);
        botonCancelar = findViewById(R.id.botonCancelar);
    }


    /**
     * metodo privado para calcular la propina con parametros
     *
     * @param importeSinPropina
     * @return
     */
    private Bundle calcularPropina(double importeSinPropina) {
        //recoger el radio marcado
        int idRadioButtonElegido = radioGroup.getCheckedRadioButtonId();
        if (idRadioButtonElegido == R.id.radioButton15) {
            porcentaje = 15;

        } else if (idRadioButtonElegido == R.id.radioButton18) {
            porcentaje = 18;
        } else if (idRadioButtonElegido == R.id.radioButton20) {
            porcentaje = 20;
        }
        //calculamos los datos a devolver
        double valorPropina = (importeSinPropina * porcentaje) / 100;
        double resultadoConPropina = importeSinPropina + valorPropina;
        // devolvemos los datos a la primera pantalla
        Bundle b = new Bundle();
        b.putDouble(EXTRA_PROPINA, valorPropina);
        b.putDouble(EXTRA_RESULTADO_TOTAL_PAGAR, resultadoConPropina);
        return b;
    }


}