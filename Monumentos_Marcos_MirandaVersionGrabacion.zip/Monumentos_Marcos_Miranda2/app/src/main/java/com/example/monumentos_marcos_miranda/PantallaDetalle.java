package com.example.monumentos_marcos_miranda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class PantallaDetalle extends AppCompatActivity implements View.OnClickListener {

    //creamos las variables
    ImageView ivMonumento;
    EditText etDescripcion,etNombre;
    String descripcionLarga="";
    int numero;

    TextView tvAplicarCambios;

    Button botonGrabar,botonCancelar;

    public static final String EXTRA_DESCRIPCION="textoDescripcion";
    public static final String EXTRA_NUMERO_IMAGEN="imagen";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_detalle);

        etNombre = findViewById(R.id.etNombre);
        etDescripcion = findViewById(R.id.etDescripcion);
        ivMonumento = findViewById(R.id.ivMonumento);
        botonGrabar=findViewById(R.id.botonGrabar);                 //añadido boton grabar
        botonCancelar=findViewById(R.id.botonCancelar);             //añadido boton cancelar
        tvAplicarCambios=findViewById(R.id.tvAplicarCambios);       //añadimos textView para etiqueta pregunta cambios

        //recuperar los datos de la activity principal

        Intent i = getIntent();
        //comprobamos que existe el intent y que existe las constantes declaradas para recuperar los datos

        if (i.hasExtra(MainActivity.EXTRA_DESCRIPCION_LARGA)) {
            descripcionLarga = i.getStringExtra(MainActivity.EXTRA_DESCRIPCION_LARGA);
            etDescripcion.setText(descripcionLarga);
        }
        if (i.hasExtra(MainActivity.EXTRA_IMAGEN)) {
            int numeroImagen = i.getIntExtra(MainActivity.EXTRA_IMAGEN, 0);
            numero=numeroImagen;
            pasarFoto(numeroImagen);
        }

        //hacemos listener para los botones creados GRABAR Y CANCELAR
        setListenerToButtons();
    }

    private void setListenerToButtons() {
        botonGrabar.setOnClickListener(this);
        botonCancelar.setOnClickListener(this);
    }


    // establecemos texto, imagen y titulo de cada monumento
    private void pasarFoto (int i){
            switch(i){
                case 0:
                    etNombre.setText(MainActivity.listaMonumentos.get(0).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(0).getFotoId());
                    //etDescripcion.setText(MainActivity.listaMonumentos.get(0).toStringDetalleCompleto());
                    break;
                    case 1:
                    etNombre.setText(MainActivity.listaMonumentos.get(1).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(1).getFotoId());
                    //etDescripcion.setText(MainActivity.listaMonumentos.get(1).toStringDetalleCompleto());
                    break;
                    case 2:
                    etNombre.setText(MainActivity.listaMonumentos.get(2).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(2).getFotoId());
                    //etDescripcion.setText(MainActivity.listaMonumentos.get(2).toStringDetalleCompleto());
                    break;
                    case 3:
                    etNombre.setText(MainActivity.listaMonumentos.get(3).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(3).getFotoId());
                    //etDescripcion.setText(MainActivity.listaMonumentos.get(3).toStringDetalleCompleto());
                    break;
                    case 4:
                    etNombre.setText(MainActivity.listaMonumentos.get(4).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(4).getFotoId());
                    //etDescripcion.setText(MainActivity.listaMonumentos.get(4).toStringDetalleCompleto());
                    break;
                    case 5:
                    etNombre.setText(MainActivity.listaMonumentos.get(5).getNombre());
                    ivMonumento.setImageResource(MainActivity.listaMonumentos.get(5).getFotoId());
                    //etDescripcion.setText(MainActivity.listaMonumentos.get(5).toStringDetalleCompleto());
                    break;

            }
        }


    @Override
    public void onClick(View view) {
        int id=view.getId();
        if(id==R.id.botonCancelar){
            finish();
        } else {
            String datoModificado=etDescripcion.getText().toString();
            Intent resultIntent=new Intent();
            resultIntent.putExtra(EXTRA_DESCRIPCION,datoModificado);
            resultIntent.putExtra(EXTRA_NUMERO_IMAGEN,numero);
            setResult(RESULT_OK,resultIntent);
            finish();

        }


    }
}