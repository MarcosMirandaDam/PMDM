package com.example.monumentos_marcos_miranda;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    //creamos la lista de monumentos para almacenarlos a partir de la clase Monumento creada.
    public static List<Monumento> listaMonumentos=new ArrayList<>();

    public List<Monumento> getListaMonumentos (){

        listaMonumentos.add(new Monumento("1", getString(R.string.nombreArco), getString(R.string.ubicacion1), 1553, getString(R.string.nombreArq1), getString(R.string.sexo1), getString(R.string.pais1), getString(R.string.descripcion1), true,getString(R.string.estilo1),34,R.drawable.arco_santa_maria));
        listaMonumentos.add(new Monumento("2", getString(R.string.monumento2), getString(R.string.ubicacion2), 1221, getString(R.string.arquitecto2), getString(R.string.sexo2), getString(R.string.pais2), getString(R.string.descripcion2), true,getString(R.string.estilo2),89,R.drawable.catedral_burgos));
        listaMonumentos.add(new Monumento("3", getString(R.string.monumento3), getString(R.string.ubicacion3), 1441, getString(R.string.arquitecto3), getString(R.string.sexo3), getString(R.string.pais3), getString(R.string.descripcion3), true,getString(R.string.estilo3),89,R.drawable.cartuja));
        listaMonumentos.add(new Monumento("4", getString(R.string.monumento4), getString(R.string.ubicacion4), 1968, getString(R.string.arquitecto4), getString(R.string.sexo4), getString(R.string.pais4), getString(R.string.descripcion4), true,getString(R.string.estilo4),24,R.drawable.cordon));
        listaMonumentos.add(new Monumento("5", getString(R.string.monumento5), getString(R.string.ubicacion5), 1955, getString(R.string.arquitecto5), getString(R.string.sexo5), getString(R.string.pais5), getString(R.string.descripcion5), false,getString(R.string.estilo5),10,R.drawable.el_cid));
        listaMonumentos.add(new Monumento("6", getString(R.string.monumento6), getString(R.string.ubicacion6), 1181, getString(R.string.arquitecto6), getString(R.string.sexo6), getString(R.string.pais6), getString(R.string.descripcion6), false,getString(R.string.estilo6),34,R.drawable.huelgas));
        return listaMonumentos;
    }


    //declaramos las vistas necesarias
    private EditText etBienvenida, etDescripcion,etTitulo;
    private ImageView ivMonumento;
    private Button botonOtro;

    private Button botonVerDetalles;

    // declaramos la constante para pasar dato a la segunda pantalla(activity)
    public final static String EXTRA_DESCRIPCION="descripcion";
    public final static String EXTRA_DESCRIPCION_LARGA="descripcionLarga";

    public final static String EXTRA_IMAGEN="imagen";



    // variable que recogeré el valor del random
    int numero;
    String descripcionLarga="";

    // declaramos el lanzador, siempre antes del onCreate
    private ActivityResultLauncher<Intent>launcherPantallaDetalle;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //iniciamos referencias de las vistas
        initReferences();

        //inicializamos en el OnCreate la lista de monumentos
        listaMonumentos=getListaMonumentos();

        //lanzamos el random
        hacerRandom();

        // accion del boton verDetalles.... lanzará a la segunda activity
        botonVerDetalles.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lanzarPantallaDetalle();
            }
        });

        // boton que cambia el monumento que se esta visualizando en la pantalla principal
        botonOtro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero=hacerRandom();
            }
        });

        //registramos el lanzador
        launcherPantallaDetalle=registroDevolucionPantallaDetalle();


    }

    /**
     * metodo que registra la devolucion de llamda de resultados provenientes de la otra Activity
     * @return
     */
    private ActivityResultLauncher<Intent> registroDevolucionPantallaDetalle() {
        return registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        //codigo que se ejecuta cuando la segunda activity devuelve control a esta
                        if(result.getResultCode()==RESULT_OK){
                            Intent data=result.getData();
                            completarCampos(data);

                        }
                    }
                }
        );
    }

    private void completarCampos(Intent data) {
        etDescripcion.setText(data.getStringExtra(PantallaDetalle.EXTRA_DESCRIPCION));

    }


    // metodo privado que lanza la otra pantalla de detalle
    private void lanzarPantallaDetalle() {
        Intent iPantallaDetalle = new Intent(this, PantallaDetalle.class);

        // pasamos los textos de la pantalla principal

        String descripcion= listaMonumentos.get(numero).toStringCorto();
        String descripcionLarga=listaMonumentos.get(numero).toStringDetalleCompleto();

        //creamos Bundle para pasar grupo de constantes
        Bundle bundle=new Bundle();

        bundle.putString(EXTRA_DESCRIPCION, descripcion);
        bundle.putString(EXTRA_DESCRIPCION_LARGA, descripcionLarga);
        bundle.putInt(EXTRA_IMAGEN,numero);

        iPantallaDetalle.putExtras(bundle);

        launcherPantallaDetalle.launch(iPantallaDetalle);


    }



    //hacemos el random para que salga la imagen y su descripcion
    private int hacerRandom() {
        Random random = new Random();
        int numero = random.nextInt(6);
        switch (numero){
            case 0:
            ivMonumento.setImageResource(listaMonumentos.get(0).getFotoId());
            etDescripcion.setText(listaMonumentos.get(numero).toStringCorto());
            //descripcionLarga=getString(R.string.descripcion1);
            break;

            case 1:
            ivMonumento.setImageResource(listaMonumentos.get(1).getFotoId());
            etDescripcion.setText(listaMonumentos.get(numero).toStringCorto());
            //descripcionLarga=getString(R.string.descripcion2);
            break;

            case 2:
            ivMonumento.setImageResource(listaMonumentos.get(2).getFotoId());
            etDescripcion.setText(listaMonumentos.get(numero).toStringCorto());
            //descripcionLarga=getString(R.string.descripcion3);
            break;

            case 3:
            ivMonumento.setImageResource(listaMonumentos.get(3).getFotoId());
            etDescripcion.setText(listaMonumentos.get(numero).toStringCorto());
            //descripcionLarga=getString(R.string.descripcion4);
            break;

            case 4:
            ivMonumento.setImageResource(listaMonumentos.get(4).getFotoId());
            etDescripcion.setText(listaMonumentos.get(numero).toStringCorto());
            //descripcionLarga=getString(R.string.descripcion5);
             break;

            case 5:
                ivMonumento.setImageResource(listaMonumentos.get(5).getFotoId());
                etDescripcion.setText(listaMonumentos.get(numero).toStringCorto());
                //descripcionLarga=getString(R.string.descripcion6);
                break;

        }

      return numero;
    }



    //metodo privado que inicializa las vistas xml

    private void initReferences(){
        etTitulo=findViewById(R.id.etTitulo);
        etBienvenida=findViewById(R.id.etBienvenida);
        etDescripcion=findViewById(R.id.etDescripcion);
        botonVerDetalles=findViewById(R.id.botonDetalles);
        botonOtro=findViewById(R.id.botonOtro);
        ivMonumento=findViewById(R.id.ivMonumento);
    }


    /**
     * metodo para guardar datos cambio pantalla
     * @param savedInstanceState Bundle in which to place your saved state.
     *
     */
    @Override
    protected void onSaveInstanceState( Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putString(EXTRA_DESCRIPCION,etDescripcion.getText().toString());
        savedInstanceState.putInt(EXTRA_IMAGEN,numero);

    }

    /**
     * metodo que recupera los datos cambio pantalla
     * @param savedInstanceState the data most recently supplied in {@link #onSaveInstanceState}.
     *
     */
    @Override
    protected void onRestoreInstanceState( Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        etDescripcion.setText(savedInstanceState.getString(EXTRA_DESCRIPCION));
        numero=savedInstanceState.getInt(EXTRA_IMAGEN,0);
        ivMonumento.setImageResource((listaMonumentos.get(numero).getFotoId()));

    }
}