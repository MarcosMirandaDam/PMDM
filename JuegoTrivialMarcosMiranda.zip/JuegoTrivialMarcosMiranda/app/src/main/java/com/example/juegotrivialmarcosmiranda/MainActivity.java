package com.example.juegotrivialmarcosmiranda;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    //creamos la unidad de almacenamiento
    public static List<Pregunta> listaPreguntas = new ArrayList<>();

    public List<Pregunta> getListaPreguntas() {
        listaPreguntas.add(new Pregunta("1", "¿Cuál es la capital de Italia?", "Roma", "Paris", "Venecia", "Viena", "Roma","Geografia"));
        listaPreguntas.add(new Pregunta("2", "¿Qué río pasa por Alemania?", "Rin", "Sena", "Po", "Ebro", "Rin","Geografia"));
        listaPreguntas.add(new Pregunta("3", "¿Quién pintó Las Meninas?", "Goya", "Picasso", "Dali", "Velazquez", "Velazquez","Arte y Literatura"));
        listaPreguntas.add(new Pregunta("4", "¿Quién escribió La Regenta?", "Leopoldo Alas Clarin", "Cervantes", "Federico Gª Lorca", "Gloria Fuertes", "Leopoldo Alas Clarin","Arte y Literatura"));
        listaPreguntas.add(new Pregunta("5", "¿Cómo se llaman los animales que comen de todo?", "Herviboro", "Carnivoros", "Omnivoros", "Pannívoro", "Omnivoros","Ciencias"));
        listaPreguntas.add(new Pregunta("6", "¿Cuántos MB son 1GB?", "0.1MB", "0.01MB", "1024MB", "102410MB", "1024MB","Ciencias"));
        listaPreguntas.add(new Pregunta("7", "¿Quién ganó el Mundial de Fútbol en 2010?", "Alemania", "Francia", "Inglaterra", "España", "España","Deportes"));
        listaPreguntas.add(new Pregunta("8", "¿Qué deporte practica Carlos Alcaraz?", "Futbol", "Atletismo", "Beisbol", "Tenis", "Tenis","Deportes"));

        return listaPreguntas;
    }

    //declaramos las variables de las vistas necesarias
    private ImageView ivGeografia, ivArte, ivCiencias, ivDeportes;
    private TextView tvMarcadorGeo, tvMarcadorArte, tvMarcadorCiencias, tvMarcadorDeportes, tvEligeCategoria, tvArte, tvGeografia, tvCiencias, tvDeportes;
    private ImageButton ibGeografia, ibArte, ibCiencias, ibDeportes;


    //declaramos las constantes para pasar a la segunda pantalla

    public final static String  EXTRA_NUMERO="numero";
    public final static String  EXTRA_R1="respuesta1";
    public final static String  EXTRA_R2="respuesta2";
    public final static String  EXTRA_R3="respuesta3";
    public final static String  EXTRA_R4 ="respuesta4";
    public final static String  EXTRA_ENUNCIADO ="enunciado";

    public final static String EXTRA_NOMBRE_CATEGORIA="categoria";

    //declaramos el launcher para la segunda pantalla
    private ActivityResultLauncher<Intent> launcherSegundaPantalla;

    //variables a necesitar
    int numero;                //recoge el valor del random

    int puntos=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //iniciamos las vistas
        initRefences();

        //iniciamos la lista de preguntas
        listaPreguntas = getListaPreguntas();

        //lanzamos el random
        //hacerRandom();

        //escuchadores de los botones
        setListenersToButtons();

        //registramos el lanzador
        launcherSegundaPantalla = registroDevolucionSegundaPantalla();
    }

    private ActivityResultLauncher<Intent> registroDevolucionSegundaPantalla() {
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        //codigo que se ejecuta cuando la segunda pantalla devuelve datos a esta
                        if(result.getResultCode()==RESULT_OK){
                            Intent data=result.getData();
                            completarDatos(data);
                        }
                    }
                });
    }

    private void completarDatos(Intent data) {
        //aqui pintamos los campos de la pantalla principal deseados
    }

    private void setListenersToButtons() {
        ibDeportes.setOnClickListener(this::onClick);
        ibArte.setOnClickListener(this::onClick);
        ibGeografia.setOnClickListener(this::onClick);
        ibCiencias.setOnClickListener(this::onClick);
    }

    private void onClick(View view) {
        ibDeportes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero=7;
                lanzarSegundaPantalla();
            }
        });
        ibCiencias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero=5;
                lanzarSegundaPantalla();
            }
        });
        ibGeografia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero=1;
                lanzarSegundaPantalla();
            }
        });
        ibArte.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                numero=3;
                lanzarSegundaPantalla();
            }
        });
    }

    private void lanzarSegundaPantalla() {
        Intent iSegundaPantalla=new Intent(this, SegundaPantalla.class);

        //tomamos los datos para pasar a la segunda pantalla

        String categoria=listaPreguntas.get(numero).getCategoria();
        String enunciado=listaPreguntas.get(numero).getEnunciado();
        String respuesta1=listaPreguntas.get(numero).getRespuesta1();
        String respuesta2=listaPreguntas.get(numero).getRespuesta2();
        String respuesta3=listaPreguntas.get(numero).getRespuesta3();
        String respuesta4=listaPreguntas.get(numero).getRespuesta4();

        //creamos Bundle para pasarlos
        Bundle bundle=new Bundle();
        bundle.putString(EXTRA_NOMBRE_CATEGORIA,categoria);
        bundle.putString(EXTRA_ENUNCIADO,enunciado);
        bundle.putString(EXTRA_R1,respuesta1);
        bundle.putString(EXTRA_R2,respuesta2);
        bundle.putString(EXTRA_R3,respuesta3);
        bundle.putString(EXTRA_R4,respuesta4);
        bundle.putInt(EXTRA_NUMERO,numero);

        iSegundaPantalla.putExtras(bundle);

        launcherSegundaPantalla.launch(iSegundaPantalla);

    }

    private int hacerRandom() {
        Random random = new Random();
        int numero = random.nextInt();
        switch (numero) {
            case 0:
                numero = 0;
                break;
            case 1:
                numero = 1;
                break;

        }
        return numero;
    }

    private void initRefences() {
        ivGeografia = findViewById(R.id.ivGeografia);
        tvGeografia = findViewById(R.id.tvMarcadorGeo);
        ivArte = findViewById(R.id.ivArte);
        tvArte = findViewById(R.id.tvMarcadorArte);
        ivCiencias = findViewById(R.id.ivCiencias);
        tvCiencias = findViewById(R.id.tvMarcadorCiencias);
        ivDeportes = findViewById(R.id.ivDeportes);
        tvDeportes = findViewById(R.id.tvMarcadorDeportes);
        tvEligeCategoria = findViewById(R.id.tvEligeCategoria);
        ibGeografia = findViewById(R.id.ibGeografia);
        tvGeografia = findViewById(R.id.tvArte);
        ibArte = findViewById(R.id.ibArte);
        tvArte = findViewById(R.id.tvArte);
        ibCiencias = findViewById(R.id.ibCiencias);
        tvCiencias = findViewById(R.id.tvCiencias);
        ibDeportes = findViewById(R.id.ibDeportes);
        tvDeportes = findViewById(R.id.tvDeportes);


    }
}