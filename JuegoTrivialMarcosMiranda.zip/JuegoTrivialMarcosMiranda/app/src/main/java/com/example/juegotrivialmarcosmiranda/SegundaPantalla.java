package com.example.juegotrivialmarcosmiranda;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

public class SegundaPantalla extends AppCompatActivity {

    //declaramos las variables existentes en el diseño
    private TextView tvNombreCategoriaSelecc,tvEnunciadoPregunta,tvEtiquetaPista;
    private Button botonRespuesta1,botonRespuesta2,botonRespuesta3,botonRespuesta4,botonVolver;

    private CheckBox cbDesactivarUnaRespuesta,cbPrimeraLetra;

    // declaramos variable para devolver datos a la primera pantalla
    public static final String EXTRA_PUNTUACION="puntuacion";
    int numero;
    int puntuacion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_pantalla);

        //iniciar vistas
        initReferences();

        //recuperar los datos de la primera pantalla
        Intent i=getIntent();
        Bundle bundle=i.getExtras();
        numero=i.getIntExtra(MainActivity.EXTRA_NUMERO,0);
        String nombreCategoria=i.getStringExtra(MainActivity.EXTRA_NOMBRE_CATEGORIA);
        tvNombreCategoriaSelecc.setText(nombreCategoria);
        String enunciado=i.getStringExtra(MainActivity.EXTRA_ENUNCIADO);
        tvEnunciadoPregunta.setText(enunciado);
        String respuesta1=i.getStringExtra(MainActivity.EXTRA_R1);
        botonRespuesta1.setText(respuesta1);
        String respuesta2=i.getStringExtra(MainActivity.EXTRA_R2);
        botonRespuesta2.setText(respuesta2);
        String respuesta3=i.getStringExtra(MainActivity.EXTRA_R3);
        botonRespuesta3.setText(respuesta3);
        String respuesta4=i.getStringExtra(MainActivity.EXTRA_R4);
        botonRespuesta4.setText(respuesta4);

        setListenerToButtons();


    }

    private void setListenerToButtons() {
        botonVolver.setOnClickListener(this::onClick);
        botonRespuesta1.setOnClickListener(this::onClick);
        botonRespuesta2.setOnClickListener(this::onClick);
        botonRespuesta3.setOnClickListener(this::onClick);
        botonRespuesta4.setOnClickListener(this::onClick);
    }

    private void onClick(View view) {
        int id= view.getId();
        if(id==R.id.botonRespuesta1){
            
        }
    }

    private void initReferences() {
        tvNombreCategoriaSelecc=findViewById(R.id.tvNombreCategoriaSelecc);
        tvEnunciadoPregunta=findViewById(R.id.tvEnunciadoPregunta);
        botonRespuesta1=findViewById(R.id.botonRespuesta1);
        botonRespuesta2=findViewById(R.id.botonRespuesta2);
        botonRespuesta3=findViewById(R.id.botonRespuesta3);
        botonRespuesta4=findViewById(R.id.botonRespuesta4);
        tvEtiquetaPista=findViewById(R.id.tvEtiquetaPista);
        cbDesactivarUnaRespuesta=findViewById(R.id.cbDesactivarUnaRespuesta);
        cbPrimeraLetra=findViewById(R.id.cbPrimeraLetra);
        botonVolver=findViewById(R.id.botonVolver);
    }
}