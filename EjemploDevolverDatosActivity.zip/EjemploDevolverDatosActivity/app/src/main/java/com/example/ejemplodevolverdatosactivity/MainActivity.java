package com.example.ejemplodevolverdatosactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    //declaramos las variables
    private TextView tvTitulo,tvImporte,tvSimboloMoneda,tvPropinaEtiqueta,tvValorPropina,tvTotalPagarEtiqueta,tvTotalPagar;
    private EditText editTextImporte;

    private Button botonPropina;

    private View view;

    //declaramos la constante necesaria para almacenar el importe
    public final static String EXTRA_IMPORTE="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();

        /**
         * boton que lanza la segunda activity
         */
        botonPropina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                lanzarCalcularPropinaActivity();
            }
        });


    }

    /**
     * metodo que inicializa las vistas
     */
    private void initReferences(){
        tvTitulo=findViewById(R.id.tvTitulo);
        tvImporte=findViewById(R.id.tvImporte);
        tvSimboloMoneda=findViewById(R.id.tvSimboloMoneda);
        tvPropinaEtiqueta=findViewById(R.id.tvPropinaEtiqueta);
        tvValorPropina=findViewById(R.id.tvValorPropina);
        tvTotalPagarEtiqueta=findViewById(R.id.tvTotalPagarEtiqueta);
        tvTotalPagar=findViewById(R.id.tvTotalPagar);
        editTextImporte=findViewById(R.id.editTextImporte);
        view=findViewById(R.id.view);
        botonPropina=findViewById(R.id.botonPropina);

    }

    private void lanzarCalcularPropinaActivity(){
        Intent iCalcularPropinaActivity=new Intent(this,CalcularPropinaActivity.class);

        //pasamos el importe de la propina a la segunda activity
        String importe=editTextImporte.getText().toString();

        iCalcularPropinaActivity.putExtra(EXTRA_IMPORTE,importe);

        startActivity(iCalcularPropinaActivity);

    }




}