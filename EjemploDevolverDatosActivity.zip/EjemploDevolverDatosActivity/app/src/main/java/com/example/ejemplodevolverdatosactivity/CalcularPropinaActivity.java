package com.example.ejemplodevolverdatosactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class CalcularPropinaActivity extends AppCompatActivity {

    //declaramos las variables a utilizar.
    private TextView tvImporteSinPropinaEtiqueta,tvValorImporteSinPropina,tvSimboloMoneda,tvPorcentaje;

    private RadioGroup radioGroup;
    private RadioButton radioButton15,radioButton20,radioButton18;

    private Button botonCalcular,botonCancelar;

    String importePropina="";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calcular_propina);

        // declaramos las vistas de las variables instanciadas arriba
        tvImporteSinPropinaEtiqueta=findViewById(R.id.tvImporteSinPropinaEtiqueta);
        tvValorImporteSinPropina=findViewById(R.id.tvValorImporteSinPropina);
        tvSimboloMoneda=findViewById(R.id.tvSimboloMoneda);
        tvPorcentaje=findViewById(R.id.tvPorcentaje);
        radioGroup=findViewById(R.id.radioGroup);
        radioButton15=findViewById(R.id.radioButton15);
        radioButton20=findViewById(R.id.radioButton20);
        radioButton18=findViewById(R.id.radioButton18);
        botonCalcular=findViewById(R.id.botonCalcular);
        botonCancelar=findViewById(R.id.botonCancelar);

        //recuperamos los datos de la primera activity
        Intent i=getIntent();

        importePropina= (i.getStringExtra(String.valueOf(MainActivity.EXTRA_IMPORTE)));
        tvValorImporteSinPropina.setText(importePropina);


        // damos accion a los botones creados



    }




}