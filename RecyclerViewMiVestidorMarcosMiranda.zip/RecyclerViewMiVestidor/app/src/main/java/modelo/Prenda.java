package modelo;

import android.graphics.drawable.Drawable;

public class Prenda {

    private String nombre;
    private String talla;
    private String ubicacion;
    private Drawable imagen;

    public Prenda(String nombre, String talla, String ubicacion, Drawable imagen) {
        this.nombre = nombre;
        this.talla = talla;
        this.ubicacion = ubicacion;
        this.imagen = imagen;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTalla() {
        return talla;
    }

    public void setTalla(String talla) {
        this.talla = talla;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public Drawable getImagen() {
        return imagen;
    }

    public void setImagen(Drawable imagen) {
        this.imagen = imagen;
    }

    @Override
    public String toString() {
        return "Prenda{" +
                "nombre='" + nombre + '\'' +
                ", talla='" + talla + '\'' +
                ", ubicacion='" + ubicacion + '\'' +
                ", imagen=" + imagen +
                '}';
    }
}



