package com.example.recyclerviewmivestidor;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import modelo.Prenda;

public class PantallaDetalle extends AppCompatActivity {

    public static final String EXTRA_POSICION_ARRAY = "posicion_array";
    private TextView tvNombrePrenda,tvTalla,tvUbicacion;
    private Button botonVolver;

    private ImageView ivPrenda;

    //objeto Prenda
    private Prenda prenda;
    // variable posicion del array
    private int pos=-1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_detalle);

        initReferences();

        //recojo la constante que viene de la pantalla principal
        if(getIntent().hasExtra(EXTRA_POSICION_ARRAY)){
            pos=getIntent().getIntExtra(EXTRA_POSICION_ARRAY,-1);
        } if(pos!=-1){
            prenda=MainActivity.listaPrendas.get(pos);
            mostrar(prenda);
        }

        botonVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });


    }

    private void mostrar(Prenda prenda) {
        ivPrenda.setImageDrawable(prenda.getImagen());
        tvNombrePrenda.setText(prenda.getNombre());
        tvUbicacion.setText(prenda.getUbicacion());
        tvTalla.setText(prenda.getTalla());

    }

    private void initReferences() {
        tvTalla=findViewById(R.id.tvTalla);
        tvNombrePrenda=findViewById(R.id.tvNombrePrenda);
        tvUbicacion=findViewById(R.id.tvUbicacion);
        botonVolver=findViewById(R.id.botonVolver);
        ivPrenda=findViewById(R.id.ivPrenda);


    }
}