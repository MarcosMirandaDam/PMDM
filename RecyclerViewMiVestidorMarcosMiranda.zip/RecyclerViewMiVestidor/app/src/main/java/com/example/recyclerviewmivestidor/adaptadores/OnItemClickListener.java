package com.example.recyclerviewmivestidor.adaptadores;

public interface OnItemClickListener {
}
