package com.example.recyclerviewmivestidor.adaptadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recyclerviewmivestidor.R;

import java.util.List;

import modelo.Prenda;

public class AdaptadorPrendas extends RecyclerView.Adapter<AdaptadorPrendas.PrendasViewHolder> {
    //datos
    List<Prenda> listaPrendas;

    //declaramos escuchador OnItemclicks
    private OnItemClickListener mListener;

    //constructor
    public AdaptadorPrendas(List<Prenda> listaPrendas) {
        this.listaPrendas = listaPrendas;
    }

    //Método que asigna el escuchador listener a mi escuchador de OnItemClicks eventos
    public void setOnItemClickListener(OnItemClickListener listener){
        this.mListener=listener;
    }

    @NonNull
    @Override
    public AdaptadorPrendas.PrendasViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista_prendas,parent,false);

        return new PrendasViewHolder(itemView,mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorPrendas.PrendasViewHolder holder, int position) {
        Prenda prenda=listaPrendas.get(position);
        holder.bindPrenda(prenda);

    }

    //devolvemos el tamaño de la lista
    @Override
    public int getItemCount() {
        return listaPrendas.size();
    }

    //interface del onclicklistener
    public interface OnItemClickListener{
        // el parámetro será la posición que ocupa en la lista el equipo pulsado
        void onItemClick(int posicion);
    }

    public static class PrendasViewHolder extends RecyclerView.ViewHolder{
        //declarar las variables de cada item
        private ImageView ivPrenda;
        private TextView tvNombrePrenda,tvTalla,tvUbicacion;

        public PrendasViewHolder(@NonNull View itemView, OnItemClickListener listener) {
            super(itemView);
            //asignando listener de clicks
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // llamo a mi listener pasándole el equipo sobre el que se hizo click y su posición
                    if (listener != null) {
                        listener.onItemClick(getAdapterPosition());
                    }


                }
            });
            ivPrenda=itemView.findViewById(R.id.ivPrenda);
            tvNombrePrenda=itemView.findViewById(R.id.tvNombrePrenda);
            tvTalla=itemView.findViewById(R.id.tvTalla);
            tvUbicacion=itemView.findViewById(R.id.tvUbicacion);
        }

        public void bindPrenda(Prenda prenda) {
            ivPrenda.setImageDrawable(prenda.getImagen());
            tvNombrePrenda.setText(prenda.getNombre());
            tvTalla.setText(prenda.getTalla());
            tvUbicacion.setText(prenda.getUbicacion());

        }
    }
}
