package com.example.recyclerviewmivestidor.adaptadores;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.recyclerviewmivestidor.R;

import java.util.List;

import modelo.Prenda;

public class AdaptadorPrendas extends RecyclerView.Adapter<AdaptadorPrendas.PrendasViewHolder> {
    List<Prenda> listaPrendas;

    public AdaptadorPrendas(List<Prenda> listaPrendas) {
        this.listaPrendas = listaPrendas;
    }

    @NonNull
    @Override
    public AdaptadorPrendas.PrendasViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista_prendas,parent,false);

        return new PrendasViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorPrendas.PrendasViewHolder holder, int position) {
        Prenda prenda=listaPrendas.get(position);
        holder.bindPrenda(prenda);

    }

    @Override
    public int getItemCount() {
        return listaPrendas.size();
    }


    public static class PrendasViewHolder extends RecyclerView.ViewHolder{
        //declarar las variables de cada item
        private ImageView ivPrenda;
        private TextView tvNombrePrenda,tvTalla,tvUbicacion;

        public PrendasViewHolder(@NonNull View itemView) {
            super(itemView);
            ivPrenda=itemView.findViewById(R.id.ivPrenda);
            tvNombrePrenda=itemView.findViewById(R.id.tvNombrePrenda);
            tvTalla=itemView.findViewById(R.id.tvTalla);
            tvUbicacion=itemView.findViewById(R.id.tvUbicacion);
        }

        public void bindPrenda(Prenda prenda) {
            ivPrenda.setImageDrawable(prenda.getImagen());
            tvNombrePrenda.setText(prenda.getNombre());
            tvTalla.setText(prenda.getTalla());
            tvUbicacion.setText(prenda.getUbicacion());

        }
    }
}
