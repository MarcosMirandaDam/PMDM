package com.example.recyclerviewmivestidor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;

import com.example.recyclerviewmivestidor.adaptadores.AdaptadorPrendas;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import modelo.Prenda;

public class MainActivity extends AppCompatActivity {

    //unidad de almacenamiento static para acceder despues desde PantallaDetalle
    static List<Prenda> listaPrendas;

    // declaramos variables de las vistas

   private TextView tvTitulo,tvTotalPrendas;
   private Button botonOrdenar,botonTotal;
   private RecyclerView rvVestidor;

    private AdaptadorPrendas adaptadorPrendas;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();

        //cargar datos del arrays.xml
        cargarDatos();

        //configurar la recyclerView
        configurarRecyclerView();

        setListenersToButtons();



    }

    private void setListenersToButtons() {
        botonOrdenar.setOnClickListener(this::onClick);
        botonTotal.setOnClickListener(this::onClick);
    }

    private void onClick(View view) {
        botonTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvTotalPrendas.setText(String.valueOf(listaPrendas.size()));
            }
        });

        botonOrdenar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Collections.sort(listaPrendas,Collections.reverseOrder());
                adaptadorPrendas.notifyDataSetChanged();
            }
        });
    }

    private void configurarRecyclerView() {
        adaptadorPrendas=new AdaptadorPrendas((listaPrendas));
        adaptadorPrendas.setOnItemClickListener(new AdaptadorPrendas.OnItemClickListener() {

            @Override
            public void onItemClick(int posicion) {
                // Este código se ejecutará cuando se pulse click en un elemento de la lista
                // Debemos programar que lance la activity VerEquipo sabiendo la posición que fue pulsada.
                lanzarActivityVerEquipo(posicion);
            }
        });
        rvVestidor.setAdapter(adaptadorPrendas);
        //distribucion del layout
        rvVestidor.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
    }

    private void lanzarActivityVerEquipo(int posicion) {
        Intent i=new Intent(this,PantallaDetalle.class);
        i.putExtra(PantallaDetalle.EXTRA_POSICION_ARRAY,posicion);
        startActivity(i);
    }

    private void cargarDatos() {
        String[] nombresPrendas=getResources().getStringArray(R.array.nombre_prenda);
        String[] tallas=getResources().getStringArray(R.array.tallas);
        String[] ubicaciones=getResources().getStringArray(R.array.ubicaciones);
        TypedArray imagenes=getResources().obtainTypedArray(R.array.imagen_prenda);  //saco imagenes del arrays.xml
        Drawable[] imagenesPrendas=new Drawable[imagenes.length()];                  //creo array Drawable
        for (int i = 0; i < imagenes.length(); i++) {
            imagenesPrendas[i]=imagenes.getDrawable(i);
            
        }
        //relleno el arrayList de las prendas
        listaPrendas=new ArrayList<>();
        for (int i = 0; i <imagenesPrendas.length ; i++) {
            listaPrendas.add(new Prenda(nombresPrendas[i],tallas[i],ubicaciones[i],imagenesPrendas[i]));

        }
        imagenes.recycle();


    }


    private void initReferences() {
        tvTitulo=findViewById(R.id.tvTitulo);
        rvVestidor=findViewById(R.id.rvVestidor);
        botonOrdenar=findViewById(R.id.botonOrdenar);
        botonTotal=findViewById(R.id.botonTotal);
        tvTotalPrendas=findViewById(R.id.tvTotalPrendas);

    }
}