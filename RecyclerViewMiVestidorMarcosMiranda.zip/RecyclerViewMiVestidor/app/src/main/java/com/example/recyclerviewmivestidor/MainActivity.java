package com.example.recyclerviewmivestidor;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.widget.TextView;

import com.example.recyclerviewmivestidor.adaptadores.AdaptadorPrendas;

import java.util.ArrayList;
import java.util.List;

import modelo.Prenda;

public class MainActivity extends AppCompatActivity {

    //unidad de almacenamiento
    private List<Prenda> listaPrendas;

    // declaramos variables de las vistas

   private TextView tvTitulo;
   private RecyclerView rvVestidor;

    private AdaptadorPrendas adaptadorPrendas;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();

        //cargar datos del arrays.xml
        cargarDatos();

        //configurar la recyclerView
        configurarRecyclerView();


    }

    private void configurarRecyclerView() {
        adaptadorPrendas=new AdaptadorPrendas(listaPrendas);
        //asigno el adaptador
        rvVestidor.setAdapter(adaptadorPrendas);
        //distribucion del layout
        rvVestidor.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
    }

    private void cargarDatos() {
        String[] nombresPrendas=getResources().getStringArray(R.array.nombre_prenda);
        String[] tallas=getResources().getStringArray(R.array.tallas);
        String[] ubicaciones=getResources().getStringArray(R.array.ubicaciones);
        TypedArray imagenes=getResources().obtainTypedArray(R.array.imagen_prenda);  //saco imagenes del arrays.xml
        Drawable[] imagenesPrendas=new Drawable[imagenes.length()];                  //creo array Drawable
        for (int i = 0; i < imagenes.length(); i++) {
            imagenesPrendas[i]=imagenes.getDrawable(i);
            
        }
        //relleno el arrayList de las prendas
        listaPrendas=new ArrayList<>();
        for (int i = 0; i <imagenesPrendas.length ; i++) {
            listaPrendas.add(new Prenda(nombresPrendas[i],tallas[i],ubicaciones[i],imagenesPrendas[i]));

        }


    }


    private void initReferences() {
        tvTitulo=findViewById(R.id.tvTitulo);
        rvVestidor=findViewById(R.id.rvVestidor);

    }
}