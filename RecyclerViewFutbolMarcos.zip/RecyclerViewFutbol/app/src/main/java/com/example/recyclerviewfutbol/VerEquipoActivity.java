package com.example.recyclerviewfutbol;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.recyclerviewfutbol.modelo.Equipo;

public class VerEquipoActivity extends AppCompatActivity {

    // VIEWS
    TextView tvNombre,tvPuntos,tvNumeroJugadores;
    ImageView ivEscudo;
    //variable
    private int pos=-1;
    //objeto Equipo
    private Equipo equipo;
    //constante
    public final static String EXTRA_POSICION_ARRAY="posicion_array";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_equipo);

        initReferences();

        //recojo la constante que viene de la pantalla principal
        if(getIntent().hasExtra(EXTRA_POSICION_ARRAY)){
            pos=getIntent().getIntExtra(EXTRA_POSICION_ARRAY,-1);
        } if(pos!=-1){
            equipo=MainActivity.listaEquipos.get(pos);
            mostrar(equipo);
        }


    }

    private void mostrar(Equipo equipo) {
        ivEscudo.setImageDrawable(equipo.getEscudo());
        tvNombre.setText(equipo.getNombre());
        tvPuntos.setText(String.valueOf(equipo.getPuntos()));
        tvNumeroJugadores.setText(String.valueOf(equipo.getNumeroJugadores()));
    }

    private void initReferences() {
        tvNombre=findViewById(R.id.tvNombreEquipo);
        tvPuntos=findViewById(R.id.tvPuntos);
        tvNumeroJugadores=findViewById(R.id.tvNumeroJugadores);
        ivEscudo=findViewById(R.id.ivEscudo);

    }
}