package com.example.recyclerviewfutbol;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;

import com.example.recyclerviewfutbol.adaptadores.AdaptadorEquipos;
import com.example.recyclerviewfutbol.modelo.Equipo;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {;

    //unidad de almacenamiento de datos
    static List<Equipo> listaEquipos;
    // declarar variables del diseño
    private TextView tvTitulo;

    // la recyclerView
    private RecyclerView rvListaEquipos;

    // adaptadores
    private AdaptadorEquipos adaptadorEquipos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        cargarDatos();

        //iniciamos referencias
        initReferences();

        configurarRecyclerView();



    }

    private void configurarRecyclerView() {
        adaptadorEquipos=new AdaptadorEquipos((listaEquipos));
        adaptadorEquipos.setOnItemClickListener(new AdaptadorEquipos.OnItemClickListener() {
            @Override
            public void onItemClick(int posicion) {
                // Este código se ejecutará cuando se pulse click en un elemento de la lista
                // Debemos programar que lance la activity VerEquipo sabiendo la posición que fue pulsada.
                lanzarActivityVerEquipo(posicion);
            }

            
        });
        //asigno el adaptador
        rvListaEquipos.setAdapter(adaptadorEquipos);
        //distribucion del layout
        rvListaEquipos.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,false));
    }

    private void lanzarActivityVerEquipo(int posicion) {
        Intent i=new Intent(this,VerEquipoActivity.class);
        i.putExtra(VerEquipoActivity.EXTRA_POSICION_ARRAY,posicion);
        startActivity(i);
    }

    private void initReferences() {
        tvTitulo=findViewById(R.id.tvTitulo);
        rvListaEquipos=findViewById(R.id.rvListaEquipos);
    }

    private void cargarDatos() {
        //extraer datos del xml
        String[] nombres= getResources().getStringArray(R.array.nombre_equipo);   //extraemos los nombres
        int[] puntos= getResources().getIntArray(R.array.puntos_equipo);            //extraemo los puntos
        TypedArray array= getResources().obtainTypedArray(R.array.escudo_equipo);   // para extraer las imagenes
        Drawable[] imagenesEscudos=new Drawable[array.length()];
        for (int i = 0; i < imagenesEscudos.length; i++){
            imagenesEscudos[i]=array.getDrawable(i);
        }
        //rellenamos el arrayList de equipos
        listaEquipos=new ArrayList<>();
        for (int i = 0; i < imagenesEscudos.length; i++) {
            listaEquipos.add(new Equipo(nombres[i], imagenesEscudos[i], puntos[i], 22));

        }

    }
}