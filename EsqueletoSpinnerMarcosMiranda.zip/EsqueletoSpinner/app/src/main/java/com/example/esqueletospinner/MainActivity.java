package com.example.esqueletospinner;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    //unidad de almacenamiento para los enteros

    private Spinner spPersonas,spEdades;

    private TextView tvTitulo,tvMarcosMiranda,tvEtiPersona,tvEtiEdad,tvEtiPregunta,tvResultado;
    private Button botonComprobar;

    private ArrayAdapter<CharSequence> adaptadorPersonas;
    private ArrayAdapter<Integer> adaptadorEdades;

    //variables para logica

    String personaElegida,edadElegida;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //init referencias
        initReferences();

        //configurar el spinner de personas
        configurarSpinnerPersonas();
        //configurar el spinner de edades
        configurarSpinnerEdades();

        botonComprobar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch(personaElegida){
                    case "Mariana":
                        if(personaElegida.equals("Mariana")&&edadElegida.equals("46")){
                            tvResultado.setText("Correcto !!!");
                            tvResultado.setBackgroundColor(Color.GREEN);
                        } else {
                            tvResultado.setText("Incorrecto !!!");
                            tvResultado.setBackgroundColor(Color.RED);
                            tvResultado.setTextColor(Color.WHITE);
                        }
                        break;
                    case "Martina":
                        if(personaElegida.equals("Martina")&&edadElegida.equals("7")){
                            tvResultado.setText("Correcto !!!");
                            tvResultado.setBackgroundColor(Color.GREEN);
                        } else {
                            tvResultado.setText("Incorrecto !!!");
                            tvResultado.setBackgroundColor(Color.RED);
                            tvResultado.setTextColor(Color.WHITE);
                        }
                        break;
                    case "Marcos":
                        if(personaElegida.equals("Marcos")&&edadElegida.equals("47")){
                            tvResultado.setText("Correcto !!!");
                            tvResultado.setBackgroundColor(Color.GREEN);
                        } else {
                            tvResultado.setText("Incorrecto !!!");
                            tvResultado.setBackgroundColor(Color.RED);
                            tvResultado.setTextColor(Color.WHITE);
                        }
                        break;
                }

            }
        });
        





    }

    private void configurarSpinnerEdades() {
        //cargamos los datos al ser un Integer mejor de esta manera
        Integer[] edades={7,47,46};
        adaptadorEdades=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,edades);
        adaptadorEdades.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spEdades.setAdapter(adaptadorEdades);
        //accion de cada item
        spEdades.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                edadElegida=String.valueOf(adapterView.getItemAtPosition(position).toString());

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(MainActivity.this,"No has elegido nada",Toast.LENGTH_LONG).show();
            }
        });
    }

    private void configurarSpinnerPersonas() {
        // le decimos donde estan los datos y se los pasamos
        adaptadorPersonas=ArrayAdapter.createFromResource(this,R.array.nombres, android.R.layout.simple_spinner_item);
        adaptadorPersonas.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPersonas.setAdapter(adaptadorPersonas);
        //accion de cada item
        spPersonas.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
            personaElegida=adapterView.getItemAtPosition(position).toString();

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(MainActivity.this,"No has elegido nada",Toast.LENGTH_LONG).show();
            }
        });
    }

    private void initReferences() {
        tvTitulo=findViewById(R.id.tvTitulo);
        tvMarcosMiranda=findViewById(R.id.tvMarcosMiranda);
        tvEtiEdad=findViewById(R.id.tvEtiEdad);
        tvEtiPersona=findViewById(R.id.tvEtiPersona);
        tvEtiPregunta=findViewById(R.id.tvEtiPregunta);
        tvResultado=findViewById(R.id.tvResultado);
        spPersonas=findViewById(R.id.spPersonas);
        spEdades=findViewById(R.id.spEdades);
        botonComprobar=findViewById(R.id.botonComprobar);


    }
}