package com.example.esqueletorecycler;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

public class SegundaPantalla extends AppCompatActivity {

    //unidad de almancenamiento
    static List<Pala> listaPalas;
    public static final String EXTRA_POSICION_ARRAY = "posicion_array";
    private TextView tvMarca,tvNombrePala;
    private ImageView ivImagenPala;

    //objeto Pala
    private Pala pala;
    //variable posicion del array
    private int pos=-1;
    private Button botonMostrarDatos,botonCancelar;

    //variables para devolver a la primera pantalla
    String marcaDevolver,nombrePalaDevolver,precioDevolver;
    //constantes que llevaremos a la primera pantalla
    public static String EXTRA_MARCA_DEVOLVER="marcaDevolver";
    public static String EXTRA_NOMBRE_PALA_DEVOLVER="nombrePalaDevolver";
    public static String EXTRA_PRECIO_DEVOLVER="precioDevolver";



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_pantalla);

        initReferences();

        //cogemos los datos que vienen de la primera pantalla
       if(getIntent().hasExtra(EXTRA_POSICION_ARRAY)){
           pos=getIntent().getIntExtra(EXTRA_POSICION_ARRAY,-1);
       }
       if(pos !=-1){
           pala=MainActivity.listaPalas.get(pos);
           mostrar(pala);
       }

        setListenerToButtons();




    }

    private void mostrar(Pala pala) {
        ivImagenPala.setImageDrawable(pala.getImagen());
        tvMarca.setText(pala.getMarca());
        tvNombrePala.setText(pala.getNombrePala());

    }

    private void setListenerToButtons() {
        botonMostrarDatos.setOnClickListener(this::onClick);
        botonCancelar.setOnClickListener(this::onClick);
    }

    private void onClick(View view) {
        botonCancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        botonMostrarDatos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent resultIntent=new Intent();
                marcaDevolver= pala.getMarca();
                nombrePalaDevolver=pala.getNombrePala();
                precioDevolver = pala.getPrecio();


                resultIntent.putExtra(EXTRA_MARCA_DEVOLVER,marcaDevolver);
                resultIntent.putExtra(EXTRA_NOMBRE_PALA_DEVOLVER,nombrePalaDevolver);
                resultIntent.putExtra(EXTRA_PRECIO_DEVOLVER,precioDevolver);

                setResult(RESULT_OK,resultIntent);
                finish();

            }
        });

    }

    private void initReferences() {
        tvMarca=findViewById(R.id.tvMarca);
        tvNombrePala=findViewById(R.id.tvNombrePala);
        ivImagenPala=findViewById(R.id.ivImagenPala);
        botonMostrarDatos=findViewById(R.id.botonMostrar);
        botonCancelar=findViewById(R.id.botonCancelar);
    }
}