package com.example.esqueletorecycler;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //unidad de almacenamiento
    static List<Pala> listaPalas;
    //variables del diseño
    private TextView tvTitulo,tvEtiMarcosMiranda,tvMarcaTraida,tvNombreTraido,tvPrecioTraido;
    private RecyclerView rvPalasPadel;

    //declaramos el adptador
    private AdaptadoPalas adaptadorPalas;

    //declaramos un launcher
    private ActivityResultLauncher<Intent> launcher;

    private ImageView ivPalaTraida;

    //constante utilizar para pasar a segunda pantalla
    public static final String EXTRA_POSICION_ARRAY="posicion_array";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //init References
        initReferences();
        //cargar datos a la recycler
        cargarDatos();
        //configurarRecyclerView
        configurarRecycler();
        //registramos el launcher
        launcher=registroDevolucionDatos();
        
        

    }

    private ActivityResultLauncher<Intent> registroDevolucionDatos() {
        return registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
                new ActivityResultCallback<ActivityResult>() {
                    @Override
                    public void onActivityResult(ActivityResult result) {
                        if(result.getResultCode()==RESULT_OK){
                            Intent data=result.getData();
                            completarCampos(data);
                        }
                    }
                });
    }

    private void completarCampos(Intent data) {
        //pintamos los componentes de la primera pantalla que deseemos
        tvMarcaTraida.setText(data.getStringExtra(SegundaPantalla.EXTRA_MARCA_DEVOLVER));
        tvNombreTraido.setText(data.getStringExtra(SegundaPantalla.EXTRA_NOMBRE_PALA_DEVOLVER));
        tvPrecioTraido.setText(data.getStringExtra(SegundaPantalla.EXTRA_PRECIO_DEVOLVER));



    }

    private void configurarRecycler() {
        //le pasamos el adaptador
        adaptadorPalas=new AdaptadoPalas(listaPalas);
        rvPalasPadel.setAdapter(adaptadorPalas);
        rvPalasPadel.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
        adaptadorPalas.setOnItemClickListener(new AdaptadoPalas.OnItemClickListener() {
            @Override
            public void onItemClick(int posicion) {
                // Este código se ejecutará cuando se pulse click en un elemento de la lista
                ivPalaTraida.setImageDrawable(listaPalas.get(posicion).getImagen());
                //tvNombreTraido.setText(listaPalas.get(posicion).getNombrePala());
                //tvMarcaTraida.setText(listaPalas.get(posicion).getMarca());
                lanzarSegundaPantalla(posicion);

            }
        });


    }

    private void lanzarSegundaPantalla(int posicion) {
        //pasamos los valores a la segunda pantalla
        Intent iSegundaPantalla=new Intent(this,SegundaPantalla.class);
        iSegundaPantalla.putExtra(SegundaPantalla.EXTRA_POSICION_ARRAY,posicion);
        launcher.launch(iSegundaPantalla);


    }

    private void cargarDatos() {
        String[]marcas=getResources().getStringArray(R.array.marcas);
        String[]nombresPalas=getResources().getStringArray(R.array.nombresPalas);
        String[]precios=getResources().getStringArray(R.array.precios);
        String[]pesos=getResources().getStringArray(R.array.pesos);
        TypedArray imagenes=getResources().obtainTypedArray(R.array.imagenesPalas);
        Drawable[]imagenesPalas=new Drawable[imagenes.length()];
        for (int i = 0; i <imagenes.length() ; i++) {
            imagenesPalas[i]=imagenes.getDrawable(i);
        }
        //rellenamos el arraylist de las palas
        listaPalas=new ArrayList<>();
        for (int i = 0; i < imagenesPalas.length; i++) {
            listaPalas.add(new Pala(marcas[i],nombresPalas[i],precios[i],pesos[i],imagenesPalas[i]));

        }
        imagenes.recycle();

    }

    private void initReferences() {
        tvTitulo=findViewById(R.id.tvTitulo);
        tvEtiMarcosMiranda=findViewById(R.id.tvEtiMarcosMiranda);
        rvPalasPadel=findViewById(R.id.rvPalasPadel);
        tvMarcaTraida=findViewById(R.id.tvMarcaTraida);
        tvNombreTraido=findViewById(R.id.tvNombreTraido);
        ivPalaTraida=findViewById(R.id.ivPalaTraida);
        tvPrecioTraido = findViewById(R.id.tvPrecioTraido);

    }
}