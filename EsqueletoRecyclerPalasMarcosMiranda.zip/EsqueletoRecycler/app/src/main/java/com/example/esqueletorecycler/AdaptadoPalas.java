package com.example.esqueletorecycler;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class AdaptadoPalas extends RecyclerView.Adapter<AdaptadoPalas.PalasViewholder> {

    //datos
    List<Pala> listaPalas;

    //constructor
    public AdaptadoPalas(List<Pala> listaPalas) {
        this.listaPalas = listaPalas;
    }

    //declaramos escuchador OnItemclicks
    private OnItemClickListener mListener;

    //Método que asigna el escuchador listener a mi escuchador de OnItemClicks eventos
    public void setOnItemClickListener(OnItemClickListener listener){
        this.mListener=listener;
    }
    //interface del onclicklistener
    public interface OnItemClickListener{
        // el parámetro será la posición que ocupa en la lista el equipo pulsado
        void onItemClick(int posicion);
    }



    @NonNull
    @Override
    public AdaptadoPalas.PalasViewholder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista_palas,parent,false);
        return new PalasViewholder(itemView,mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadoPalas.PalasViewholder holder, int position) {
    Pala pala=listaPalas.get(position);
    holder.bindPala(pala);
    }

    @Override
    public int getItemCount() {
        return listaPalas.size();
    }

    public static class PalasViewholder extends RecyclerView.ViewHolder{
        //declarar las vistas de cada item
        private ImageView ivPala;
        private TextView tvMarca,tvNombrePala,tvPrecio,tvPeso;


        public PalasViewholder(@NonNull View itemView, OnItemClickListener listener) {
            super(itemView);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    // llamo a mi listener pasándole el equipo sobre el que se hizo click y su posición
                    if (listener != null) {
                        listener.onItemClick(getAdapterPosition());
                    }
                }
            });
            ivPala=itemView.findViewById(R.id.ivImagenPala);
            tvMarca=itemView.findViewById(R.id.tvMarca);
            tvNombrePala=itemView.findViewById(R.id.tvNombrePala);
            tvPrecio=itemView.findViewById(R.id.tvPrecio);
            tvPeso=itemView.findViewById(R.id.tvPeso);
        }

        public void bindPala(Pala pala) {
            ivPala.setImageDrawable(pala.getImagen());
            tvMarca.setText(pala.getMarca());
            tvNombrePala.setText(pala.getNombrePala());
            tvPrecio.setText(pala.getPrecio());
            tvPeso.setText(pala.getPeso());


        }
    }
}
