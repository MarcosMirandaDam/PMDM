package com.example.esqueletorecycler;

import android.graphics.drawable.Drawable;

public class Pala {

    private String marca, nombrePala,precio,peso;
    private Drawable imagen;

    public Pala(String marca, String nombrePala, String precio, String peso, Drawable imagen) {
        this.marca = marca;
        this.nombrePala = nombrePala;
        this.precio = precio;
        this.peso = peso;
        this.imagen = imagen;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getNombrePala() {
        return nombrePala;
    }

    public void setNombrePala(String nombrePala) {
        this.nombrePala = nombrePala;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public Drawable getImagen() {
        return imagen;
    }

    public void setImagen(Drawable imagen) {
        this.imagen = imagen;
    }

    @Override
    public String toString() {
        return "Pala{" +
                "marca='" + marca + '\'' +
                ", nombrePala='" + nombrePala + '\'' +
                ", precio='" + precio + '\'' +
                ", peso='" + peso + '\'' +
                ", imagen=" + imagen +
                '}';
    }
}
