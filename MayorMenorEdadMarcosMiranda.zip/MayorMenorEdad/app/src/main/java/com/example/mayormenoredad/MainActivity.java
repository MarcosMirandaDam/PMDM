package com.example.mayormenoredad;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etTextoNombre,etTextoEdad;
    Button botonAceptar;

    TextView resultado;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initReferences();



    botonAceptar.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

    if(!etTextoNombre.getText().toString().isEmpty() && !etTextoEdad.getText().toString().isEmpty()) {
        int edad=0;
        try {
                edad = Integer.parseInt(etTextoEdad.getText().toString());
            if (edad >= 18) {
                resultado.setVisibility(View.VISIBLE);
                resultado.setText("Es mayor de edad");
            } else {
                resultado.setVisibility(View.VISIBLE);
                resultado.setText("Es menor de edad");
            }

        } catch (NumberFormatException e){
            Toast.makeText(MainActivity.this, "Edad debe ser numérica", Toast.LENGTH_SHORT).show();
            resultado.setVisibility(View.INVISIBLE);

        }

        }
     else{
        Toast.makeText(MainActivity.this, "Hay campos vacíos, revise por favor!", Toast.LENGTH_SHORT).show();
        resultado.setVisibility(View.INVISIBLE);
    }


    }
});

    }




    private void initReferences() {
        etTextoNombre=findViewById(R.id.etTextoNombre);
        etTextoEdad=findViewById(R.id.etTextoEdad);
        botonAceptar=findViewById(R.id.botonAceptar);
        resultado=findViewById(R.id.tvResultado);


    }
}