package com.example.ejemplospinner;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //unidades de almacenamiento
    private String[] tiposProcesadores;

    private List<String> listaProductos;

    private List<String> carritoCompra;


    //declaramos las variables
    private Spinner spProcesadores;                         //toma los datos de []String
    private Spinner spEstadosCiviles;                       //toma los datos del arrays.xml

    private Spinner spPaises;                               // toma los datos del arrays.xml

    private Spinner spProductos;                             //toma datos arrayList<String>

    private Spinner spCarroCompra;                          // se rellena en tiempo de ejecución al añadir carrito

     Button botonAniadirAlCarrito,botonBorrarCarrito;


    //ADAPTADORES DE LOS SPINNERS
    private ArrayAdapter<String> adaptadorProcesadores;     //declaramos el adaptador

    private ArrayAdapter<CharSequence> adaptadorEstadosCiviles;     // declaramos el adaptador
    private ArrayAdapter<CharSequence> adaptadorPaises;

    private ArrayAdapter<String> adaptadorProductos;

    private ArrayAdapter<String> adaptadorCarrito;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //iniciamos las vistas
        initReferences();

        //configuramos el spinner de procesadores cargando datos de un String[]
        configurarSpinnerProcesadores();

        // configuramos el spinner de los estados civiles cogiendo datos del arrays.xml

        configurarSpinnerEstadosCiviles();

        //configuramos el spinner de los paises tambien con datos del arrays.xml

        configurarSpinnerPaises();

        //configuramos el spinner de los productos a añadir al carro de la compra. datos de arrayList<String>

        configurarSpinnerProductos();

        // accion de los botones

        setListenersToButtons();

        //configuramos spinner carrito de la compra, los datos se añaden a un ArrayList<String>

        configurarSpinnerCarroCompra();








    }

    private void configurarSpinnerCarroCompra() {
        //iniciamos el arrayList
        carritoCompra=new ArrayList<>();
        //configuramos spinner
        adaptadorCarrito = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, carritoCompra);
        adaptadorCarrito.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spCarroCompra.setAdapter(adaptadorCarrito);
        spCarroCompra.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long l) {
                String elegido = adapterView.getItemAtPosition(position).toString();
                Toast.makeText(MainActivity.this, "Has elegido " + elegido, Toast.LENGTH_SHORT).show();

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Toast.makeText(MainActivity.this, "No has elegido nada", Toast.LENGTH_SHORT).show();

            }
        });

    }

    private void setListenersToButtons() {
        botonAniadirAlCarrito.setOnClickListener(this::OnClick);
        botonBorrarCarrito.setOnClickListener(this::OnClick);
    }

    private void OnClick(View view) {
        String productoElegido=(String)spProductos.getSelectedItem();
        int pos=adaptadorCarrito.getPosition(productoElegido);
        if(view.getId()==R.id.botonAñadir){
            if(pos<0){
                adaptadorCarrito.add(productoElegido);
                adaptadorCarrito.notifyDataSetChanged();
                spCarroCompra.setSelection(adaptadorCarrito.getPosition(productoElegido));
            }else{
                Toast.makeText(this, "Ese producto ya está en el carrito" , Toast.LENGTH_SHORT).show();
            }
        }else{
            if(pos>=0){
                adaptadorCarrito.remove(productoElegido);
                adaptadorCarrito.notifyDataSetChanged();
            }else{
                Toast.makeText(this, "Ese producto no está en el carrito", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void configurarSpinnerProductos() {
        // inicializamos arrayList y añadimos productos
        listaProductos=new ArrayList<>();
        listaProductos.add("Seleccione...");
        listaProductos.add("Leche");
        listaProductos.add("Pan");
        listaProductos.add("Huevos");
        listaProductos.add("Champú");
        listaProductos.add("Café");
        listaProductos.add("Galletas");
        //instanciamos y le decimos que tome datos de listaProductos
        adaptadorProductos=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,listaProductos);
        adaptadorProductos.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spProductos.setAdapter(adaptadorProductos);
        //accion al seleccionar item
        spProductos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                String elegido = adapterView.getItemAtPosition(position).toString();
                Toast.makeText(MainActivity.this, "Has elegido " + elegido, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(MainActivity.this, "No has elegido nada", Toast.LENGTH_SHORT).show();
            }
        });


    }

    private void configurarSpinnerPaises() {
        //le decimos donde estan los datos y se los pasamos
        adaptadorPaises=ArrayAdapter.createFromResource(this,R.array.paises, android.R.layout.simple_spinner_item);
        adaptadorPaises.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spPaises.setAdapter(adaptadorPaises);
        //accion de cada item interior
        spPaises.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                String elegido=adapterView.getItemAtPosition(position).toString();
                Toast.makeText(adapterView.getContext(),"Has elegido " + elegido, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Toast.makeText(MainActivity.this, "No has elegido nada", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void configurarSpinnerEstadosCiviles() {
        // le decimos donde estan los datos y se los pasamos
        adaptadorEstadosCiviles=ArrayAdapter.createFromResource(this,R.array.estados_civiles, android.R.layout.simple_spinner_item);
        adaptadorEstadosCiviles.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spEstadosCiviles.setAdapter(adaptadorEstadosCiviles);
        //accion de cada item interior
        spEstadosCiviles.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                String elegido = adapterView.getItemAtPosition(position).toString();
                Toast.makeText(MainActivity.this, "Has elegido " + elegido, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Toast.makeText(MainActivity.this, "No has elegido nada", Toast.LENGTH_SHORT).show();
            }
        });


    }

    private void configurarSpinnerProcesadores() {
        // cargamos los datos
        tiposProcesadores=new String[]{"Elige uno", "i3", "i5", "i7", "i9"};
        //configuramos el spinner
        adaptadorProcesadores=new ArrayAdapter<>(this, android.R.layout.simple_spinner_item,tiposProcesadores);
        adaptadorProcesadores.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spProcesadores.setAdapter(adaptadorProcesadores);
        // la acción del item interior
        spProcesadores.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int position, long id) {
                if(position!=0){
                    String elegido=adapterView.getItemAtPosition(position).toString();
                    Toast.makeText(adapterView.getContext(),"Has elegido "+elegido, Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                Toast.makeText(adapterView.getContext(),"No has seleccionado nada",Toast.LENGTH_SHORT).show();
            }
        });
    }


    private void initReferences() {
        spProcesadores=findViewById(R.id.spProcesadores);
        spEstadosCiviles=findViewById(R.id.spEstadoCivil);
        spPaises=findViewById(R.id.spPaises);
        spProductos=findViewById(R.id.spProductos);
        botonAniadirAlCarrito=findViewById(R.id.botonAñadir);
        botonBorrarCarrito=findViewById(R.id.botonBorrarCarrito);
        spCarroCompra=findViewById(R.id.spArticulos);

    }


}