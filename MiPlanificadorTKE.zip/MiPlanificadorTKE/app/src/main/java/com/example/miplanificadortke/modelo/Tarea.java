package com.example.miplanificadortke.modelo;

import android.graphics.drawable.Drawable;

public class Tarea {

    private String nombreTarea;
    private int numeroProyecto;
    private int numeroPasarela;

    private Drawable imagen;

    public Tarea(String nombreTarea, int numeroProyecto, int numeroPasarela, Drawable imagen) {
        this.nombreTarea = nombreTarea;
        this.numeroProyecto = numeroProyecto;
        this.numeroPasarela = numeroPasarela;
        this.imagen = imagen;
    }

    public String getNombreTarea() {
        return nombreTarea;
    }

    public void setNombreTarea(String nombreTarea) {
        this.nombreTarea = nombreTarea;
    }

    public int getNumeroProyecto() {
        return numeroProyecto;
    }

    public void setNumeroProyecto(int numeroProyecto) {
        this.numeroProyecto = numeroProyecto;
    }

    public int getNumeroPasarela() {
        return numeroPasarela;
    }

    public void setNumeroPasarela(int numeroPasarela) {
        this.numeroPasarela = numeroPasarela;
    }

    public Drawable getImagen() {
        return imagen;
    }

    public void setImagen(Drawable imagen) {
        this.imagen = imagen;
    }

    @Override
    public String toString() {
        return "Tarea{" +
                "nombreTarea='" + nombreTarea + '\'' +
                ", numeroProyecto=" + numeroProyecto +
                ", numeroPasarela=" + numeroPasarela +
                ", imagen=" + imagen +
                '}';
    }
}
