package com.example.miplanificadortke;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.miplanificadortke.modelo.Tarea;

import java.util.List;

public class AdaptadorTareas extends RecyclerView.Adapter<AdaptadorTareas.TareasViewHolder> {

    //datos
    List<Tarea> listaTareas;

    //constructor
    public AdaptadorTareas(List<Tarea> listaTareas) {
        this.listaTareas = listaTareas;
    }

    // declaramos escuchador
    private OnItemClickListener mListener;

    //Método que asigna el escuchador listener a mi escuchador de OnItemClicks eventos
    public void setOnItemClickListener(OnItemClickListener listener){
        this.mListener=listener;
    }

    @NonNull
    @Override
    public AdaptadorTareas.TareasViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView= LayoutInflater.from(parent.getContext()).inflate(R.layout.item_lista_tareas,parent,false);

        return new TareasViewHolder(itemView,mListener);
    }

    @Override
    public void onBindViewHolder(@NonNull AdaptadorTareas.TareasViewHolder holder, int position) {
    Tarea tarea=listaTareas.get(position);
    holder.bindTarea(tarea);
    }

    @Override
    public int getItemCount() {
        return listaTareas.size();
    }

    public interface OnItemClickListener extends TareasViewHolder.OnItemClickListener {
        // el parámetro será la posición que ocupa en la lista el equipo pulsado
        void onItemClick(int posicion);
    }

    public static class TareasViewHolder extends RecyclerView.ViewHolder {

        private ImageView ivPasarela;
        private TextView tvNombreTarea,tvNumeroProyecto,tvNumeroPasarela;

        public TareasViewHolder(@NonNull View itemView,OnItemClickListener listener) {
            super(itemView);
            //aqui va el OnItemClickListener
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // llamo a mi listener pasándole el equipo sobre el que se hizo click y su posición
                    if (listener != null) {
                        listener.onItemClick(getAdapterPosition());
                    }
                }
            });

            //vistas de las variables
            ivPasarela=itemView.findViewById(R.id.ivPasarela);
            tvNombreTarea=itemView.findViewById(R.id.tvNombreTarea);
            tvNumeroProyecto=itemView.findViewById(R.id.tvNumeroProyecto);
            tvNumeroPasarela=itemView.findViewById(R.id.tvNumeroPasarela);
        }

        public void bindTarea(Tarea tarea) {
            ivPasarela.setImageDrawable(tarea.getImagen());
            tvNombreTarea.setText(tarea.getNombreTarea());
            tvNumeroProyecto.setText(String.valueOf(tarea.getNumeroProyecto()));
            tvNumeroPasarela.setText(String.valueOf(tarea.getNumeroPasarela()));

        }

        public interface OnItemClickListener{
            void onItemClick(int posicion);
        }
    }
}
