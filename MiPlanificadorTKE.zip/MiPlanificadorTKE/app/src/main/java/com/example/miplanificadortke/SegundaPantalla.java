package com.example.miplanificadortke;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.miplanificadortke.modelo.Tarea;

public class SegundaPantalla extends AppCompatActivity {

    private ImageView ivPasarela;
    private TextView tvNumeroProyecto, tvNumeroPasarela;
    public static final String EXTRA_POSICION_ARRAY = "posicion_array";
    //objeto Tarea
    private Tarea tarea;
    // variable posicion del array
    private int pos = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segunda_pantalla);

        initReferences();

        //recojo la constante que viene de la pantalla principal
        if (getIntent().hasExtra(EXTRA_POSICION_ARRAY)) {
            pos = getIntent().getIntExtra(EXTRA_POSICION_ARRAY, -1);
        }
        if (pos != -1) {
            tarea = MainActivity.listaTareas.get(pos);
            mostrar(tarea);
        }
    }

    private void mostrar(Tarea tarea) {
        ivPasarela.setImageDrawable(tarea.getImagen());
        tvNumeroProyecto.setText(String.valueOf(tarea.getNumeroProyecto()));
        tvNumeroPasarela.setText(String.valueOf(tarea.getNumeroPasarela()));
    }

    private void initReferences() {
        tvNumeroProyecto = findViewById(R.id.tvNumeroProyecto);
        tvNumeroPasarela = findViewById(R.id.tvNumeroPasarela);
        ivPasarela = findViewById(R.id.ivPasarela);
    }
}