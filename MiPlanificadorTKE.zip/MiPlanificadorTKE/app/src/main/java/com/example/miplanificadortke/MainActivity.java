package com.example.miplanificadortke;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.miplanificadortke.modelo.Tarea;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    //unidad de almacenamiento
    static List<Tarea> listaTareas;
    //variables de las vistas
    private TextView tvTitulo,tvEtiquetaTareas,tvNumeroTareas;
    private ImageView ivPortada;
    private RecyclerView rvListaTareas;
    private Button botonTotal;

    //declaramos el adaptador necesario
    private AdaptadorTareas adaptadorTareas;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //iniciamos referencias
        initReferences();
        // cargar los datos en la List procedente del arrays.xml
        cargarDatos();

        //configurar la recylerView
        configurarRecyclerView();

        //escuchadores
        setListenersTobuttons();




    }

    private void setListenersTobuttons() {

        botonTotal.setOnClickListener(this::onClick);
    }

    private void onClick(View view) {
        botonTotal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvNumeroTareas.setText(String.valueOf(listaTareas.size()));
            }
        });


    }

    private void configurarRecyclerView() {
        adaptadorTareas=new AdaptadorTareas(listaTareas);
        rvListaTareas.setAdapter(adaptadorTareas);
        rvListaTareas.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.VERTICAL,false));
        adaptadorTareas.setOnItemClickListener(new AdaptadorTareas.OnItemClickListener() {
            @Override
            public void onItemClick(int posicion) {
                // Este código se ejecutará cuando se pulse click en un elemento de la lista
                // Debemos programar que lance la activity SegundaPantalla sabiendo la posición que fue pulsada.
                lanzarActivityVerTarea(posicion);
            }
        });

    }

    private void lanzarActivityVerTarea(int posicion) {
        Intent i=new Intent(this,SegundaPantalla.class);
        i.putExtra(SegundaPantalla.EXTRA_POSICION_ARRAY,posicion);
        startActivity(i);
    }

    private void cargarDatos() {
        String[]nombresTareas=getResources().getStringArray(R.array.nombre_tarea);
        int[]numerosProyecto=getResources().getIntArray(R.array.numeros_Proyecto);
        int[]numerosPasarela=getResources().getIntArray(R.array.numeros_Pasarelas);
        //las imagenes
        TypedArray array=getResources().obtainTypedArray(R.array.imagen_pasarela);
        Drawable[] imagenesPbb=new Drawable[array.length()];
        for (int i = 0; i < imagenesPbb.length; i++) {
            imagenesPbb[i]=array.getDrawable(i);
         }
        //rellenamos el arrayList de tareas
        listaTareas=new ArrayList<>();
        for (int i = 0; i < imagenesPbb.length; i++) {
            listaTareas.add(new Tarea(nombresTareas[i],numerosProyecto[i],numerosPasarela[i],imagenesPbb[i]));

        }

    }

    private void initReferences() {
        tvTitulo=findViewById(R.id.tvTitulo);
        tvEtiquetaTareas=findViewById(R.id.tvEtiquetaTareas);
        tvNumeroTareas=findViewById(R.id.tvNumeroTareas);
        ivPortada=findViewById(R.id.ivPortada);
        rvListaTareas=findViewById(R.id.rvListaTareas);
        botonTotal=findViewById(R.id.botonTotal);

    }
}